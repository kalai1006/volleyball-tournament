# Zoho Volleyball Tournament

<div align="center">
  <h1>🏐 Volleyball Tournament Management System</h1>
  <p>Real-time tournament management for Zoho's internal volleyball tournament</p>
  
  <img src="https://img.shields.io/badge/React-18.2-blue" />
  <img src="https://img.shields.io/badge/Firebase-10.7-orange" />
  <img src="https://img.shields.io/badge/PWA-Enabled-green" />
</div>

---

## ✨ Features

| Feature | Description |
|---------|-------------|
| 🔴 **Live Scores** | Real-time score updates visible to everyone |
| 📅 **Fixtures** | Complete match schedule with court assignments |
| 🏟️ **Court Management** | Track matches across 2 courts simultaneously |
| 👥 **Team & Player Management** | Full roster management for 75+ teams |
| ✅ **Player Validation** | Prevent players from playing multiple matches simultaneously |
| 📱 **QR Code Check-in** | Teams scan QR codes to check in before matches |
| ⚡ **Real-time Sync** | All updates sync instantly across all devices |
| 📊 **Admin Dashboard** | Complete tournament control panel |
| 📱 **Mobile Responsive** | Perfect experience on phones, tablets, and desktops |
| 💾 **PWA Support** | Install as app, works offline |

---

## 🚀 Quick Start

### One-Command Setup (macOS/Linux)

```bash
chmod +x quick-setup.sh
./quick-setup.sh
```

### Manual Setup

```bash
# 1. Install dependencies
npm install

# 2. Configure Firebase
cp .env.example .env
# Edit .env with your Firebase credentials

# 3. Start development server
npm run dev
```

📖 **For complete setup instructions, see [SETUP_GUIDE.md](SETUP_GUIDE.md)**

---

## 📸 Screenshots

### Public Views
- **Home Page**: Live matches and upcoming fixtures
- **Live Scores**: Real-time score updates
- **Fixtures**: Match schedule by date and court
- **Teams**: All teams and player rosters
- **Check-in**: QR code scanning for team check-ins

### Admin Dashboard
- **Overview**: Tournament statistics
- **Teams Management**: Add/edit/delete teams
- **Players Management**: Manage player rosters
- **Match Scheduling**: Create and schedule matches
- **Live Control**: Start matches and update scores in real-time
- **Court Management**: Manage court availability

---

## 🛠️ Technology Stack

- **Frontend**: React 18 + Vite
- **Backend**: Firebase (Firestore + Authentication)
- **Real-time**: Firestore real-time listeners
- **QR Codes**: qrcode.react + html5-qrcode
- **Routing**: React Router v6
- **Date Handling**: date-fns
- **PWA**: Vite PWA Plugin

---

## 📱 Usage

### For Admins

1. **Login**: Navigate to `/login`
2. **Manage Teams**: Add teams and players
3. **Schedule Matches**: Create match fixtures
4. **Live Control**: Start matches and update scores in real-time
5. **Generate QR Codes**: Create check-in QR codes for teams

### For Players/Captains

1. **View Live Scores**: See ongoing matches with real-time updates
2. **Check Fixtures**: View match schedule
3. **View Teams**: Browse team rosters
4. **Check-in**: Scan QR code before matches

---

## 🌐 Deployment

### Firebase Hosting (Recommended)

```bash
npm run build
firebase deploy
```

### Vercel

```bash
vercel deploy --prod
```

### Netlify

```bash
netlify deploy --prod
```

---

## 🔒 Security

- ✅ Firestore security rules enforce read/write permissions
- ✅ Only authenticated admins can modify data
- ✅ Public read access for fixtures and scores
- ✅ QR code check-ins are logged with timestamps
- ✅ HTTPS enforced in production

---

## 📊 Database Schema

### Collections

```
teams/
  - id
  - name
  - category (Men/Women)
  - captainName
  - captainEmail
  - captainPhone
  - createdAt

players/
  - id
  - name
  - email
  - teamId
  - teamName
  - createdAt

matches/
  - id
  - team1Id, team2Id
  - team1Name, team2Name
  - team1Score, team2Score
  - courtId, courtNumber
  - status (scheduled/ongoing/completed)
  - scheduledTime
  - startedAt, completedAt
  - category

courts/
  - id
  - number
  - isAvailable

checkins/
  - id
  - matchId
  - teamId
  - teamName
  - checkinTime
```

---

## 🎯 Tournament Scale

- **Teams**: 70+ Men's teams, 5 Women's teams
- **Courts**: 2 courts
- **Players**: Hundreds of players
- **Matches**: Hundreds of matches
- **Concurrent Users**: Unlimited (Firebase scales automatically)

---

## 🤝 Contributing

This is an internal Zoho project. For modifications:

1. Clone the repository
2. Create a feature branch
3. Make changes
4. Test thoroughly
5. Submit for review

---

## 📄 License

Internal use only - Zoho Corporation

---

## 🐛 Troubleshooting

### Common Issues

1. **Permission denied errors**
   - Deploy Firestore rules: `firebase deploy --only firestore:rules`

2. **Real-time updates not working**
   - Check Firestore rules allow public reads

3. **Can't login**
   - Create admin user in Firebase Console > Authentication

4. **QR scanning not working**
   - Requires HTTPS (Firebase Hosting provides this)

5. **Environment variables not loading**
   - Restart dev server after editing `.env`

---

## 📞 Support

For issues or questions:
- Check [SETUP_GUIDE.md](SETUP_GUIDE.md)
- Contact Zoho IT team
- Review Firebase Console logs

---

## 🗺️ Roadmap

- [ ] Match statistics and analytics
- [ ] Tournament bracket view
- [ ] Push notifications for match start
- [ ] Player performance tracking
- [ ] Export tournament data
- [ ] Multi-language support

---

<div align="center">
  <p>Made with ❤️ for Zoho Volleyball Tournament</p>
  <p>⚡ Powered by React & Firebase</p>
</div>
