# Zoho Volleyball Tournament - User Guide

## For Participants (Players & Captains)

### Accessing the System

1. **Open the tournament website** on any device (phone, tablet, or computer)
2. **No login required** for viewing information
3. The website works on all modern browsers

---

## Main Features

### 1. Home Page (Dashboard)

When you open the website, you'll see:
- **Live Matches**: Matches currently in progress with live scores
- **Upcoming Matches**: Next scheduled matches
- **Tournament Stats**: Number of teams, courts, and live matches

### 2. Live Scores 📊

**How to access**: Click "Live Scores" in the top menu

**What you can see**:
- All matches with current scores
- Filter by:
  - All Matches
  - Live (ongoing)
  - Completed
- Scores update automatically in real-time
- Court assignments for each match
- Match timing

**Tip**: Keep this page open during the tournament to see live updates!

### 3. Fixtures 📅

**How to access**: Click "Fixtures" in the top menu

**What you can see**:
- Complete match schedule
- Navigate between days (Previous/Today/Next)
- Filter by court
- Match timings
- Team matchups
- Match status (Scheduled/Live/Completed)

**How to find your match**:
1. Select the tournament date
2. Look for your team name
3. Note the time and court number

### 4. Teams 👥

**How to access**: Click "Teams" in the top menu

**What you can see**:
- All participating teams
- Filter by:
  - All Teams
  - Men's Teams
  - Women's Teams
- Search for specific teams or captains
- Click on a team to see:
  - Captain details
  - Contact information
  - Full player list

**How to find your team**:
1. Use the search box
2. Or filter by category
3. Click "▶ Players" to expand and see roster

### 5. Check-in ✅

**How to access**: Click "Check-in" in the top menu

**For Team Captains**:

Before your match, you'll receive a QR code (from tournament organizers). To check in:

1. Go to Check-in page
2. Click "Scan QR Code" button
3. Allow camera access (if prompted)
4. Point camera at your team's QR code
5. Wait for confirmation message

**Important Notes**:
- Check in at least 10 minutes before match time
- Only scan your team's QR code
- Each team can only check in once per match
- If scanning fails, ask tournament organizers for help

---

## Tips & Best Practices

### For Players

✅ **Before the tournament**:
- Check the Teams page to verify you're listed on your team
- Save the tournament website link on your phone
- Enable notifications (if prompted)

✅ **During the tournament**:
- Check Fixtures daily for your match schedule
- Arrive 15 minutes before your match
- Keep an eye on Live Scores to track tournament progress

✅ **If you have multiple teams**:
- The system prevents players from playing in overlapping matches
- Check with organizers if you notice a scheduling conflict

### For Team Captains

✅ **Responsibilities**:
- Check in your team before each match
- Verify your player list is correct (check Teams page)
- Keep your contact information updated
- Coordinate with your team about match timings

✅ **Before each match**:
1. Check Fixtures for court and time
2. Ensure all players are present
3. Complete QR code check-in
4. Report to assigned court

---

## Frequently Asked Questions

**Q: Do I need to install an app?**
A: No! Just open the website in any browser. You can also "Add to Home Screen" on mobile for easy access.

**Q: Will scores update automatically?**
A: Yes! Keep the page open and scores will update in real-time without refreshing.

**Q: Can I view the tournament on my phone?**
A: Yes! The website works perfectly on all devices - phones, tablets, and computers.

**Q: What if I can't find my team?**
A: Use the search box on the Teams page or contact tournament organizers.

**Q: What if QR code scanning doesn't work?**
A: Make sure you're using HTTPS (the URL should start with `https://`). If it still doesn't work, contact organizers.

**Q: Can I see past matches?**
A: Yes! Go to Live Scores and filter by "Completed" to see all finished matches.

**Q: What if my match time changes?**
A: Check the Fixtures page regularly. Updates appear immediately when organizers make changes.

**Q: Does this work offline?**
A: After your first visit, basic information is cached and viewable offline. Live updates require internet.

**Q: Who do I contact for issues?**
A: Contact the tournament organizing committee or Zoho IT team.

---

## Mobile Quick Guide

### Adding to Home Screen

**iPhone/iPad**:
1. Open website in Safari
2. Tap the Share button
3. Select "Add to Home Screen"
4. Tap "Add"

**Android**:
1. Open website in Chrome
2. Tap the menu (three dots)
3. Select "Add to Home screen"
4. Tap "Add"

Now you can open the tournament app directly from your home screen!

---

## Match Day Checklist

**1 Day Before**:
- [ ] Check Fixtures page for your match time
- [ ] Verify court assignment
- [ ] Confirm all players are available

**Match Day - Before**:
- [ ] Arrive 15 minutes early
- [ ] Check in via QR code
- [ ] Warm up near your assigned court

**During Match**:
- [ ] Play fair and have fun!
- [ ] Friends can watch live scores from anywhere

**After Match**:
- [ ] Final scores appear automatically
- [ ] Check Fixtures for next match

---

## System Features Explained

### Real-time Updates ⚡
- Scores update instantly without page refresh
- Match status changes appear immediately
- All devices see the same information at the same time

### Court Management 🏟️
- Each match assigned to specific court (Court 1 or Court 2)
- Never wonder where to play
- Easy to track which court is available

### Player Validation ✓
- System prevents scheduling conflicts
- No player can be in two matches at once
- Organizers ensure fair scheduling

### Multi-device Access 📱💻
- Access from any device
- Switch devices anytime
- Your data syncs automatically

---

## Important Reminders

⚠️ **Camera Access**: QR scanning requires camera permission. Allow access when prompted.

⚠️ **Internet Connection**: Live updates need internet. Connect to Wi-Fi or mobile data.

⚠️ **Browser Compatibility**: Works best on Chrome, Safari, Firefox, or Edge. Update to latest version.

⚠️ **Fair Play**: The system tracks everything for transparency and fairness.

---

## Getting Help

**Technical Issues**:
- Check your internet connection
- Refresh the page
- Clear browser cache
- Try a different browser
- Contact IT support

**Tournament Questions**:
- Contact tournament organizers
- Check with your team captain
- Visit the help desk (if available)

---

## Enjoy the Tournament! 🏐

Have a great time competing, and may the best team win! 

Remember:
- Check fixtures regularly
- Check in before matches
- Play fair
- Have fun!

Good luck! 🎉
