# Zoho Volleyball Tournament - Setup Guide

## Complete Setup Instructions

### Step 1: Install Dependencies

```bash
cd volleyball-tournament
npm install
```

### Step 2: Create Firebase Project

1. Go to [Firebase Console](https://console.firebase.google.com/)
2. Click "Add project" or select an existing project
3. Enter project name: "Zoho Volleyball Tournament" (or any name you prefer)
4. Click Continue and follow the wizard

### Step 3: Enable Firestore Database

1. In Firebase Console, go to **Build > Firestore Database**
2. Click "Create database"
3. Select **Start in production mode** (we'll deploy our own rules)
4. Choose a location closest to you (e.g., asia-south1 for India)
5. Click "Enable"

### Step 4: Enable Authentication

1. In Firebase Console, go to **Build > Authentication**
2. Click "Get started"
3. Go to **Sign-in method** tab
4. Enable **Email/Password** authentication
5. Click "Save"

### Step 5: Create Admin User

1. In Authentication section, go to **Users** tab
2. Click "Add user"
3. Enter:
   - **Email**: admin@zoho.com (or your preferred admin email)
   - **Password**: Create a strong password
4. Click "Add user"

### Step 6: Get Firebase Configuration

1. In Firebase Console, go to **Project Settings** (gear icon)
2. Scroll down to "Your apps"
3. Click on the **Web** icon (</>)
4. Register your app with a nickname: "Volleyball Tournament Web"
5. Copy the Firebase configuration object

### Step 7: Configure Environment Variables

1. In the project root, copy `.env.example` to `.env`:
   ```bash
   cp .env.example .env
   ```

2. Open `.env` and fill in your Firebase config values:
   ```env
   VITE_FIREBASE_API_KEY=AIzaSyXXXXXXXXXXXXXXXXXXXXXXXXX
   VITE_FIREBASE_AUTH_DOMAIN=your-project.firebaseapp.com
   VITE_FIREBASE_PROJECT_ID=your-project-id
   VITE_FIREBASE_STORAGE_BUCKET=your-project.appspot.com
   VITE_FIREBASE_MESSAGING_SENDER_ID=123456789012
   VITE_FIREBASE_APP_ID=1:123456789012:web:abcdef123456
   ```

### Step 8: Deploy Firestore Rules

1. Install Firebase CLI globally:
   ```bash
   npm install -g firebase-tools
   ```

2. Login to Firebase:
   ```bash
   firebase login
   ```

3. Initialize Firebase in your project:
   ```bash
   firebase init
   ```
   - Select: **Firestore** and **Hosting**
   - Use an existing project: Select your project
   - Firestore rules file: `firestore.rules` (already created)
   - Firestore indexes file: `firestore.indexes.json` (already created)
   - Public directory: `dist`
   - Configure as single-page app: **Yes**
   - Set up automatic builds: **No**

4. Deploy Firestore rules:
   ```bash
   firebase deploy --only firestore:rules,firestore:indexes
   ```

### Step 9: Run Development Server

```bash
npm run dev
```

The app will open at `http://localhost:3000`

### Step 10: Initial Setup in Admin Panel

1. Open the app and go to `/login`
2. Login with your admin credentials
3. You'll be redirected to the Admin Dashboard

#### Add Courts:
1. Go to **Courts** tab
2. Click "+ Add Court"
3. Add Court 1 and Court 2

#### Add Teams:
1. Go to **Teams** tab
2. Click "+ Add Team"
3. Fill in team details:
   - Team name
   - Category (Men/Women)
   - Captain name
   - Captain email
   - Captain phone
4. Repeat for all 75+ teams

#### Add Players (Optional):
1. Go to **Players** tab
2. Click "+ Add Player"
3. Add players to their respective teams

#### Schedule Matches:
1. Go to **Matches** tab
2. Click "+ Schedule Match"
3. Select:
   - Team 1
   - Team 2
   - Court
   - Category
   - Scheduled time
4. Click "Schedule Match"

### Step 11: Using the System

#### For Admins:
- **Live Control Tab**: Start matches, update scores in real-time, end matches
- **Overview Tab**: See tournament statistics and live matches
- All data updates in real-time across all devices

#### For Players/Captains:
- Visit the public URL (home page)
- View **Live Scores**: See all ongoing matches with live score updates
- View **Fixtures**: Check match schedules by date and court
- View **Teams**: Browse all teams and player lists
- **Check-in**: Scan QR codes to check-in teams before matches

#### QR Code Check-in Flow:
1. Admin generates QR code for each team per match (Check-in page > Generate QR Code tab)
2. Captain scans their team's QR code before the match
3. System validates and records check-in
4. Prevents duplicate check-ins

### Step 12: Deploy to Production

#### Option 1: Firebase Hosting (Recommended)

```bash
npm run build
firebase deploy --only hosting
```

Your app will be live at: `https://your-project-id.web.app`

#### Option 2: Vercel

```bash
npm install -g vercel
vercel
```

#### Option 3: Netlify

```bash
npm install -g netlify-cli
netlify deploy --prod
```

### Step 13: Share with Participants

After deployment, share the URL with all participants:
- Players can access it from any device (phone, tablet, laptop)
- No app installation required
- Works offline after first visit (PWA feature)
- Real-time updates automatically sync

## Key Features

✅ **Real-time Score Updates**: Scores update instantly across all devices
✅ **Court Management**: Track which match is on which court
✅ **Player Validation**: Prevents players from being in multiple matches simultaneously
✅ **QR Check-in**: Teams check in using QR codes
✅ **Fixture Management**: View and manage match schedules
✅ **Live Match Control**: Start/stop matches and update scores
✅ **Mobile Responsive**: Perfect on all devices
✅ **Progressive Web App**: Install as app, works offline

## Troubleshooting

### Issue: "Permission denied" errors
**Solution**: Make sure you've deployed Firestore rules using `firebase deploy --only firestore:rules`

### Issue: Real-time updates not working
**Solution**: Check your Firestore rules and make sure reads are allowed for public

### Issue: Can't login as admin
**Solution**: Verify you created an admin user in Firebase Authentication console

### Issue: QR code scanning not working
**Solution**: Make sure you're using HTTPS (required for camera access). Firebase Hosting automatically provides HTTPS.

### Issue: Environment variables not loading
**Solution**: Make sure your `.env` file is in the project root and restart the dev server

## Support

For issues or questions, contact your Zoho IT team or the developer who set this up.

## Security Notes

- Only authenticated admins can modify data (teams, players, matches)
- Everyone can view public information (fixtures, scores, teams)
- QR code check-ins are logged with timestamps
- All data is stored securely in Firebase
- HTTPS is enforced in production

## Advanced Customization

### Adding More Courts
Simply use the Admin Dashboard > Courts tab to add more courts dynamically

### Changing Tournament Structure
Modify the database through the Admin Dashboard or Firebase Console

### Custom Branding
Edit the colors in `src/styles/App.css` (CSS variables at the top)

### Backup Data
Use Firebase Console > Firestore Database > Export data

---

**Project Status**: Production Ready ✅
**Last Updated**: June 2026
**Maintained by**: Zoho IT Team
