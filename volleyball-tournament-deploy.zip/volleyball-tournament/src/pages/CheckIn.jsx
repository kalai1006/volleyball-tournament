import React, { useState, useEffect } from 'react';
import { getAllTeams, getPlayersByTeam, submitTeamCheckin } from '../services/tournamentService';

function CheckIn() {
  const [teams, setTeams] = useState([]);
  const [selectedTeam, setSelectedTeam] = useState('');
  const [players, setPlayers] = useState([]);
  const [presentPlayers, setPresentPlayers] = useState([]);
  const [captainName, setCaptainName] = useState('');
  const [loading, setLoading] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  useEffect(() => {
    loadTeams();
  }, []);

  useEffect(() => {
    if (selectedTeam) {
      loadPlayers(selectedTeam);
    }
  }, [selectedTeam]);

  const loadTeams = async () => {
    const allTeams = await getAllTeams();
    setTeams(allTeams);
  };

  const loadPlayers = async (teamId) => {
    const teamPlayers = await getPlayersByTeam(teamId);
    setPlayers(teamPlayers);
    setPresentPlayers([]);
  };

  const handlePlayerToggle = (playerId) => {
    if (presentPlayers.includes(playerId)) {
      setPresentPlayers(presentPlayers.filter(id => id !== playerId));
    } else {
      setPresentPlayers([...presentPlayers, playerId]);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!selectedTeam || presentPlayers.length === 0) {
      alert('Please select your team and mark at least one present player');
      return;
    }

    if (!captainName.trim()) {
      alert('Please enter captain name');
      return;
    }

    setLoading(true);
    
    try {
      const team = teams.find(t => t.id === selectedTeam);
      const presentPlayerDetails = players.filter(p => presentPlayers.includes(p.id));
      
      await submitTeamCheckin({
        teamId: selectedTeam,
        teamName: team.name,
        captainName: captainName.trim(),
        presentPlayers: presentPlayerDetails.map(p => ({
          id: p.id,
          name: p.name,
          jerseyNumber: p.jerseyNumber
        })),
        checkinTime: new Date(),
        totalPresent: presentPlayers.length,
        totalPlayers: players.length
      });

      setSubmitted(true);
      setLoading(false);
    } catch (error) {
      alert('Error submitting check-in. Please try again.');
      setLoading(false);
    }
  };

  const handleReset = () => {
    setSelectedTeam('');
    setPlayers([]);
    setPresentPlayers([]);
    setCaptainName('');
    setSubmitted(false);
  };

  if (submitted) {
    const team = teams.find(t => t.id === selectedTeam);
    return (
      <div className="container">
        <div className="card">
          <div className="card-header">
            <h2 className="card-title">✅ Check-in Successful!</h2>
          </div>
          <div style={{ textAlign: 'center', padding: '40px 20px' }}>
            <div style={{ fontSize: '48px', marginBottom: '20px' }}>🏐</div>
            <h3 style={{ color: 'var(--success-color)', marginBottom: '10px' }}>
              {team.name}
            </h3>
            <p style={{ fontSize: '18px', marginBottom: '5px' }}>
              <strong>{presentPlayers.length}</strong> players present
            </p>
            <p style={{ color: 'var(--text-secondary)', marginBottom: '30px' }}>
              Captain: {captainName}
            </p>
            <button className="btn btn-primary" onClick={handleReset}>
              Check-in Another Team
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="container">
      <div className="card">
        <div className="card-header">
          <h2 className="card-title">Team Check-in</h2>
          <p style={{ color: 'var(--text-secondary)', marginTop: '10px' }}>
            Team captains: Select your team and mark players who are present
          </p>
        </div>

        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label className="form-label">Captain Name *</label>
            <input
              type="text"
              className="form-input"
              value={captainName}
              onChange={(e) => setCaptainName(e.target.value)}
              placeholder="Enter your name"
              required
            />
          </div>

          <div className="form-group">
            <label className="form-label">Select Your Team *</label>
            <select
              className="form-select"
              value={selectedTeam}
              onChange={(e) => setSelectedTeam(e.target.value)}
              required
            >
              <option value="">-- Select Team --</option>
              {teams.map(team => (
                <option key={team.id} value={team.id}>
                  {team.name} ({team.category})
                </option>
              ))}
            </select>
          </div>

          {players.length > 0 && (
            <>
              <div style={{ marginBottom: '15px' }}>
                <h3 style={{ fontSize: '18px', marginBottom: '10px' }}>
                  Mark Present Players ({presentPlayers.length}/{players.length})
                </h3>
                <p style={{ color: 'var(--text-secondary)', fontSize: '14px' }}>
                  Check the boxes for players who are present today
                </p>
              </div>

              <div style={{ 
                display: 'grid', 
                gap: '10px', 
                marginBottom: '20px',
                maxHeight: '400px',
                overflowY: 'auto',
                padding: '10px',
                border: '1px solid var(--border-color)',
                borderRadius: '8px'
              }}>
                {players.map(player => (
                  <label
                    key={player.id}
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      padding: '12px 15px',
                      background: presentPlayers.includes(player.id) 
                        ? 'var(--primary-light)' 
                        : 'var(--card-bg)',
                      border: '2px solid',
                      borderColor: presentPlayers.includes(player.id)
                        ? 'var(--primary-color)'
                        : 'var(--border-color)',
                      borderRadius: '8px',
                      cursor: 'pointer',
                      transition: 'all 0.2s'
                    }}
                  >
                    <input
                      type="checkbox"
                      checked={presentPlayers.includes(player.id)}
                      onChange={() => handlePlayerToggle(player.id)}
                      style={{ 
                        width: '20px', 
                        height: '20px', 
                        marginRight: '15px',
                        cursor: 'pointer'
                      }}
                    />
                    <div style={{ flex: 1 }}>
                      <div style={{ fontWeight: '600', marginBottom: '2px' }}>
                        {player.name}
                      </div>
                      <div style={{ fontSize: '14px', color: 'var(--text-secondary)' }}>
                        #{player.jerseyNumber}
                      </div>
                    </div>
                  </label>
                ))}
              </div>

              <button 
                type="submit" 
                className="btn btn-primary" 
                style={{ width: '100%' }}
                disabled={loading || presentPlayers.length === 0}
              >
                {loading ? 'Submitting...' : `Submit Check-in (${presentPlayers.length} players)`}
              </button>
            </>
          )}

          {selectedTeam && players.length === 0 && (
            <div style={{ 
              textAlign: 'center', 
              padding: '40px 20px',
              color: 'var(--text-secondary)' 
            }}>
              <p>No players found for this team.</p>
              <p style={{ fontSize: '14px', marginTop: '10px' }}>
                Please contact the organizers to add players to your team.
              </p>
            </div>
          )}
        </form>
      </div>
    </div>
  );
}

export default CheckIn;
