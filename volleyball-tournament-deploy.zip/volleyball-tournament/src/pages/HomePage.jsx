import React, { useState, useEffect } from 'react';
import { subscribeToOngoingMatches, subscribeToMatches } from '../services/tournamentService';
import { format } from 'date-fns';
import { isFirebaseConfigured } from '../data/demoData';

// Helper function to normalize court display
const normalizeCourtDisplay = (courtNumber) => {
  if (!courtNumber) return '';
  return courtNumber.toString().replace(/^court\s*/i, '');
};

function HomePage() {
  const [ongoingMatches, setOngoingMatches] = useState([]);
  const [upcomingMatches, setUpcomingMatches] = useState([]);
  const [loading, setLoading] = useState(true);
  const isDemoMode = !isFirebaseConfigured();

  useEffect(() => {
    const unsubscribeOngoing = subscribeToOngoingMatches((matches) => {
      setOngoingMatches(matches);
      setLoading(false);
    });

    const unsubscribeAll = subscribeToMatches((matches) => {
      const upcoming = matches.filter(m => m.status === 'scheduled').slice(0, 5);
      setUpcomingMatches(upcoming);
    });

    return () => {
      unsubscribeOngoing();
      unsubscribeAll();
    };
  }, []);

  if (loading) {
    return (
      <div className="container">
        <div className="loading">
          <div className="spinner"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="container">
      {isDemoMode && (
        <div style={{ 
          background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
          color: 'white',
          padding: '15px 20px',
          borderRadius: '8px',
          marginBottom: '20px',
          textAlign: 'center',
          boxShadow: '0 4px 6px rgba(0,0,0,0.1)'
        }}>
          <strong>🎭 DEMO MODE</strong> - You're viewing sample data. 
          To use real data, configure Firebase in the <code style={{ background: 'rgba(255,255,255,0.2)', padding: '2px 6px', borderRadius: '3px' }}>.env</code> file.
        </div>
      )}
      <section className="card">
        <div className="card-header">
          <h2 className="card-title">
            <span className="live-indicator">
              <span className="live-dot"></span>
              LIVE NOW
            </span>
          </h2>
        </div>
        {ongoingMatches.length === 0 ? (
          <p style={{ color: 'var(--text-secondary)' }}>No matches currently in progress</p>
        ) : (
          <div className="grid grid-2">
            {ongoingMatches.map(match => (
              <MatchCard key={match.id} match={match} />
            ))}
          </div>
        )}
      </section>

      <section className="card">
        <div className="card-header">
          <h2 className="card-title">Upcoming Matches</h2>
        </div>
        {upcomingMatches.length === 0 ? (
          <p style={{ color: 'var(--text-secondary)' }}>No upcoming matches scheduled</p>
        ) : (
          <div className="grid grid-2">
            {upcomingMatches.map(match => (
              <MatchCard key={match.id} match={match} />
            ))}
          </div>
        )}
      </section>

      <section className="card">
        <div className="card-header">
          <h2 className="card-title">Tournament Info</h2>
        </div>
        <div className="grid grid-3">
          <div style={{ textAlign: 'center', padding: '20px' }}>
            <h3 style={{ fontSize: '32px', color: 'var(--primary-color)', marginBottom: '5px' }}>75+</h3>
            <p style={{ color: 'var(--text-secondary)' }}>Teams</p>
          </div>
          <div style={{ textAlign: 'center', padding: '20px' }}>
            <h3 style={{ fontSize: '32px', color: 'var(--primary-color)', marginBottom: '5px' }}>2</h3>
            <p style={{ color: 'var(--text-secondary)' }}>Courts</p>
          </div>
          <div style={{ textAlign: 'center', padding: '20px' }}>
            <h3 style={{ fontSize: '32px', color: 'var(--primary-color)', marginBottom: '5px' }}>
              {ongoingMatches.length}
            </h3>
            <p style={{ color: 'var(--text-secondary)' }}>Live Matches</p>
          </div>
        </div>
      </section>
    </div>
  );
}

function MatchCard({ match }) {
  const formatTime = (timestamp) => {
    if (!timestamp) return '';
    const date = timestamp.toDate ? timestamp.toDate() : new Date(timestamp);
    return format(date, 'HH:mm');
  };
  
  const normalizeCourtDisplay = (courtNumber) => {
    if (!courtNumber) return '';
    return courtNumber.toString().replace(/^court\s*/i, '');
  };

  return (
    <div className={`match-card ${match.status}`}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '10px' }}>
        <span className="court-tag">Court {normalizeCourtDisplay(match.courtNumber)}</span>
        {match.status === 'ongoing' && (
          <span className="live-indicator">
            <span className="live-dot"></span>
            LIVE
          </span>
        )}
        {match.status === 'scheduled' && (
          <span style={{ fontSize: '14px', color: 'var(--text-secondary)' }}>
            {formatTime(match.scheduledTime)}
          </span>
        )}
      </div>
      
      <div className="match-teams">
        <div style={{ flex: 1 }}>
          <div className="team-name">{match.team1Name}</div>
          {match.category && (
            <div style={{ fontSize: '12px', color: 'var(--text-secondary)' }}>
              {match.category}
            </div>
          )}
        </div>
        <div className="match-score">
          {match.team1Score} - {match.team2Score}
        </div>
        <div style={{ flex: 1, textAlign: 'right' }}>
          <div className="team-name">{match.team2Name}</div>
        </div>
      </div>

      {match.status === 'completed' && (
        <div style={{ marginTop: '10px', textAlign: 'center' }}>
          <span className="badge badge-success">Completed</span>
        </div>
      )}
      
      {match.status === 'completed' && match.playerOfTheMatch && (
        <div style={{ 
          marginTop: '10px', 
          padding: '8px', 
          background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
          borderRadius: '6px',
          color: 'white',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          gap: '6px',
          fontSize: '13px'
        }}>
          <span>🏆</span>
          <span style={{ fontWeight: '600' }}>{match.playerOfTheMatch.playerName}</span>
        </div>
      )}
    </div>
  );
}

export default HomePage;
