import React, { useState, useEffect } from 'react';
import { subscribeToMatches } from '../services/tournamentService';
import { format } from 'date-fns';

// Helper function to normalize court display
const normalizeCourtDisplay = (courtNumber) => {
  if (!courtNumber) return '';
  return courtNumber.toString().replace(/^court\s*/i, '');
};

function LiveScores() {
  const [matches, setMatches] = useState([]);
  const [filter, setFilter] = useState('all'); // all, ongoing, completed
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const unsubscribe = subscribeToMatches((allMatches) => {
      setMatches(allMatches);
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const filteredMatches = matches.filter(match => {
    if (filter === 'all') return true;
    return match.status === filter;
  });

  if (loading) {
    return (
      <div className="container">
        <div className="loading">
          <div className="spinner"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="container">
      <div className="card">
        <div className="card-header">
          <h2 className="card-title">Live Scores</h2>
        </div>

        <div style={{ marginBottom: '20px', display: 'flex', gap: '10px' }}>
          <button
            className={`btn ${filter === 'all' ? 'btn-primary' : 'btn-secondary'}`}
            onClick={() => setFilter('all')}
          >
            All Matches
          </button>
          <button
            className={`btn ${filter === 'ongoing' ? 'btn-success' : 'btn-secondary'}`}
            onClick={() => setFilter('ongoing')}
          >
            Live ({matches.filter(m => m.status === 'ongoing').length})
          </button>
          <button
            className={`btn ${filter === 'completed' ? 'btn-secondary' : 'btn-secondary'}`}
            onClick={() => setFilter('completed')}
          >
            Completed
          </button>
        </div>

        {filteredMatches.length === 0 ? (
          <p style={{ color: 'var(--text-secondary)', textAlign: 'center', padding: '40px' }}>
            No matches found
          </p>
        ) : (
          <div className="grid grid-2">
            {filteredMatches.map(match => (
              <ScoreCard key={match.id} match={match} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

function ScoreCard({ match }) {
  const formatTime = (timestamp) => {
    if (!timestamp) return '';
    // Handle both Firebase Timestamp and regular Date objects
    const date = timestamp.toDate ? timestamp.toDate() : 
                 timestamp instanceof Date ? timestamp : new Date(timestamp);
    return format(date, 'MMM dd, HH:mm');
  };
  
  const normalizeCourtDisplay = (courtNumber) => {
    if (!courtNumber) return '';
    return courtNumber.toString().replace(/^court\s*/i, '');
  };

  return (
    <div className={`match-card ${match.status}`}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '15px' }}>
        <span className="court-tag">Court {normalizeCourtDisplay(match.courtNumber)}</span>
        {match.status === 'ongoing' && (
          <span className="live-indicator">
            <span className="live-dot"></span>
            LIVE
          </span>
        )}
        {match.status === 'completed' && (
          <span className="badge badge-success">Final</span>
        )}
      </div>

      <div style={{ marginBottom: '10px' }}>
        <div style={{ 
          display: 'flex', 
          justifyContent: 'space-between', 
          alignItems: 'center',
          padding: '10px',
          background: match.team1Score > match.team2Score && match.status === 'completed' ? '#e8f5e9' : 'transparent',
          borderRadius: '4px',
          marginBottom: '5px'
        }}>
          <div>
            <div className="team-name">{match.team1Name}</div>
            <div style={{ fontSize: '12px', color: 'var(--text-secondary)' }}>
              {match.category || 'Men\'s'}
            </div>
          </div>
          <div style={{ fontSize: '28px', fontWeight: '700', color: 'var(--primary-color)' }}>
            {match.team1Score}
          </div>
        </div>

        <div style={{ 
          display: 'flex', 
          justifyContent: 'space-between', 
          alignItems: 'center',
          padding: '10px',
          background: match.team2Score > match.team1Score && match.status === 'completed' ? '#e8f5e9' : 'transparent',
          borderRadius: '4px'
        }}>
          <div>
            <div className="team-name">{match.team2Name}</div>
          </div>
          <div style={{ fontSize: '28px', fontWeight: '700', color: 'var(--primary-color)' }}>
            {match.team2Score}
          </div>
        </div>
      </div>

      <div style={{ fontSize: '12px', color: 'var(--text-secondary)', marginTop: '10px' }}>
        {match.status === 'scheduled' && `Scheduled: ${formatTime(match.scheduledTime)}`}
        {match.status === 'ongoing' && 'Match in progress'}
        {match.status === 'completed' && match.completedAt && `Completed: ${formatTime(match.completedAt)}`}
      </div>
      
      {match.status === 'completed' && match.playerOfTheMatch && (
        <div style={{ 
          marginTop: '15px', 
          padding: '10px', 
          background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
          borderRadius: '6px',
          color: 'white',
          display: 'flex',
          alignItems: 'center',
          gap: '8px'
        }}>
          <span style={{ fontSize: '18px' }}>🏆</span>
          <div>
            <div style={{ fontSize: '11px', opacity: 0.9, marginBottom: '2px' }}>Player of the Match</div>
            <div style={{ fontWeight: '600', fontSize: '14px' }}>{match.playerOfTheMatch.playerName}</div>
          </div>
        </div>
      )}
    </div>
  );
}

export default LiveScores;
