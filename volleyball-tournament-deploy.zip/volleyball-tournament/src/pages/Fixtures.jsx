import React, { useState, useEffect } from 'react';
import { subscribeToMatches, getAllCourts } from '../services/tournamentService';
import { format, startOfDay, addDays } from 'date-fns';

// Helper function to normalize court display
const normalizeCourtDisplay = (courtNumber) => {
  if (!courtNumber) return '';
  return courtNumber.toString().replace(/^court\s*/i, '');
};

function Fixtures() {
  const [matches, setMatches] = useState([]);
  const [courts, setCourts] = useState([]);
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [selectedCourt, setSelectedCourt] = useState('all');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const unsubscribe = subscribeToMatches((allMatches) => {
      setMatches(allMatches);
      setLoading(false);
    });

    getAllCourts().then(setCourts);

    return () => unsubscribe();
  }, []);

  const filteredMatches = matches.filter(match => {
    if (!match.scheduledTime) return false;
    
    // Handle both Firebase Timestamp and regular Date objects
    const matchDate = match.scheduledTime.toDate ? 
      match.scheduledTime.toDate() : 
      match.scheduledTime instanceof Date ? match.scheduledTime : new Date(match.scheduledTime);
    const isDateMatch = format(matchDate, 'yyyy-MM-dd') === format(selectedDate, 'yyyy-MM-dd');
    
    if (selectedCourt === 'all') return isDateMatch;
    return isDateMatch && match.courtId === selectedCourt;
  });

  if (loading) {
    return (
      <div className="container">
        <div className="loading">
          <div className="spinner"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="container">
      <div className="card">
        <div className="card-header">
          <h2 className="card-title">Match Fixtures</h2>
        </div>

        <div style={{ marginBottom: '20px' }}>
          <div style={{ display: 'flex', gap: '10px', marginBottom: '15px', flexWrap: 'wrap' }}>
            <button
              className="btn btn-secondary"
              onClick={() => setSelectedDate(addDays(selectedDate, -1))}
            >
              ← Previous Day
            </button>
            <button
              className="btn btn-primary"
              onClick={() => setSelectedDate(new Date())}
            >
              Today
            </button>
            <button
              className="btn btn-secondary"
              onClick={() => setSelectedDate(addDays(selectedDate, 1))}
            >
              Next Day →
            </button>
          </div>

          <div style={{ marginBottom: '15px' }}>
            <h3 style={{ fontSize: '18px', marginBottom: '10px' }}>
              {format(selectedDate, 'EEEE, MMMM dd, yyyy')}
            </h3>
          </div>

          <div style={{ display: 'flex', gap: '10px', flexWrap: 'wrap' }}>
            <button
              className={`btn ${selectedCourt === 'all' ? 'btn-primary' : 'btn-secondary'}`}
              onClick={() => setSelectedCourt('all')}
            >
              All Courts
            </button>
            {courts.map(court => (
              <button
                key={court.id}
                className={`btn ${selectedCourt === court.id ? 'btn-primary' : 'btn-secondary'}`}
                onClick={() => setSelectedCourt(court.id)}
              >
                Court {normalizeCourtDisplay(court.number)}
              </button>
            ))}
          </div>
        </div>

        {filteredMatches.length === 0 ? (
          <p style={{ color: 'var(--text-secondary)', textAlign: 'center', padding: '40px' }}>
            No matches scheduled for this day
          </p>
        ) : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
            {filteredMatches.map(match => (
              <FixtureCard key={match.id} match={match} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

function FixtureCard({ match }) {
  const formatTime = (timestamp) => {
    if (!timestamp) return '';
    // Handle both Firebase Timestamp and regular Date objects
    const date = timestamp.toDate ? timestamp.toDate() : 
                 timestamp instanceof Date ? timestamp : new Date(timestamp);
    return format(date, 'HH:mm');
  };

  const getStatusBadge = () => {
    switch (match.status) {
      case 'ongoing':
        return <span className="badge badge-success">LIVE</span>;
      case 'completed':
        return <span className="badge badge-info">Completed</span>;
      case 'scheduled':
        return <span className="badge badge-warning">Scheduled</span>;
      default:
        return null;
    }
  };

  return (
    <div className={`match-card ${match.status}`} style={{ display: 'flex', alignItems: 'center', gap: '20px' }}>
      <div style={{ minWidth: '80px', textAlign: 'center' }}>
        <div style={{ fontSize: '24px', fontWeight: '700', color: 'var(--primary-color)' }}>
          {formatTime(match.scheduledTime)}
        </div>
        <span className="court-tag">Court {normalizeCourtDisplay(match.courtNumber)}</span>
      </div>

      <div style={{ flex: 1 }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '5px' }}>
          <span className="team-name">{match.team1Name}</span>
          {match.status !== 'scheduled' && (
            <span style={{ fontSize: '20px', fontWeight: '700' }}>{match.team1Score}</span>
          )}
        </div>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <span className="team-name">{match.team2Name}</span>
          {match.status !== 'scheduled' && (
            <span style={{ fontSize: '20px', fontWeight: '700' }}>{match.team2Score}</span>
          )}
        </div>
        {match.category && (
          <div style={{ fontSize: '12px', color: 'var(--text-secondary)', marginTop: '5px' }}>
            {match.category}
          </div>
        )}
        {match.status === 'completed' && match.playerOfTheMatch && (
          <div style={{ 
            marginTop: '8px', 
            padding: '6px 10px', 
            background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
            borderRadius: '4px',
            color: 'white',
            fontSize: '12px',
            display: 'inline-flex',
            alignItems: 'center',
            gap: '5px'
          }}>
            <span>🏆</span>
            <span style={{ fontWeight: '600' }}>{match.playerOfTheMatch.playerName}</span>
          </div>
        )}
      </div>

      <div>
        {getStatusBadge()}
      </div>
    </div>
  );
}

export default Fixtures;
