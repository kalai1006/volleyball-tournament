import React, { useState, useEffect } from 'react';
import { subscribeToTeams, subscribeToPlayers } from '../services/tournamentService';

function Teams() {
  const [teams, setTeams] = useState([]);
  const [players, setPlayers] = useState([]);
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const unsubscribeTeams = subscribeToTeams((allTeams) => {
      setTeams(allTeams);
      setLoading(false);
    });

    const unsubscribePlayers = subscribeToPlayers((allPlayers) => {
      setPlayers(allPlayers);
    });

    return () => {
      unsubscribeTeams();
      unsubscribePlayers();
    };
  }, []);

  const filteredTeams = teams.filter(team => {
    const categoryMatch = selectedCategory === 'all' || team.category === selectedCategory;
    const searchMatch = team.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                       team.captainName?.toLowerCase().includes(searchTerm.toLowerCase());
    return categoryMatch && searchMatch;
  });

  if (loading) {
    return (
      <div className="container">
        <div className="loading">
          <div className="spinner"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="container">
      <div className="card">
        <div className="card-header">
          <h2 className="card-title">Teams & Players</h2>
        </div>

        <div style={{ marginBottom: '20px' }}>
          <input
            type="text"
            className="form-input"
            placeholder="Search teams or captains..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            style={{ marginBottom: '15px' }}
          />

          <div style={{ display: 'flex', gap: '10px', flexWrap: 'wrap' }}>
            <button
              className={`btn ${selectedCategory === 'all' ? 'btn-primary' : 'btn-secondary'}`}
              onClick={() => setSelectedCategory('all')}
            >
              All Teams ({teams.length})
            </button>
            <button
              className={`btn ${selectedCategory === 'Men' ? 'btn-primary' : 'btn-secondary'}`}
              onClick={() => setSelectedCategory('Men')}
            >
              Men's ({teams.filter(t => t.category === 'Men').length})
            </button>
            <button
              className={`btn ${selectedCategory === 'Women' ? 'btn-primary' : 'btn-secondary'}`}
              onClick={() => setSelectedCategory('Women')}
            >
              Women's ({teams.filter(t => t.category === 'Women').length})
            </button>
          </div>
        </div>

        {filteredTeams.length === 0 ? (
          <p style={{ color: 'var(--text-secondary)', textAlign: 'center', padding: '40px' }}>
            No teams found
          </p>
        ) : (
          <div className="grid grid-2">
            {filteredTeams.map(team => (
              <TeamCard key={team.id} team={team} players={players.filter(p => p.teamId === team.id)} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

function TeamCard({ team, players }) {
  const [showPlayers, setShowPlayers] = useState(false);

  return (
    <div className="card" style={{ margin: 0 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '10px' }}>
        <div>
          <h3 style={{ fontSize: '18px', fontWeight: '600', marginBottom: '5px' }}>
            {team.name}
          </h3>
          {team.category && (
            <span className={`badge ${team.category === 'Women' ? 'badge-error' : 'badge-info'}`}>
              {team.category}
            </span>
          )}
        </div>
      </div>

      <div style={{ marginBottom: '10px' }}>
        <div style={{ fontSize: '14px', color: 'var(--text-secondary)', marginBottom: '3px' }}>
          👤 Captain: <strong>{team.captainName || 'Not assigned'}</strong>
        </div>
        {team.captainEmail && (
          <div style={{ fontSize: '12px', color: 'var(--text-secondary)' }}>
            ✉️ {team.captainEmail}
          </div>
        )}
        {team.captainPhone && (
          <div style={{ fontSize: '12px', color: 'var(--text-secondary)' }}>
            📱 {team.captainPhone}
          </div>
        )}
      </div>

      <div style={{ marginTop: '15px', paddingTop: '15px', borderTop: '1px solid var(--border-color)' }}>
        <button
          className="btn btn-secondary"
          style={{ width: '100%' }}
          onClick={() => setShowPlayers(!showPlayers)}
        >
          {showPlayers ? '▼' : '▶'} Players ({players.length})
        </button>

        {showPlayers && players.length > 0 && (
          <div style={{ marginTop: '10px' }}>
            {players.map((player, index) => (
              <div
                key={player.id}
                style={{
                  padding: '8px',
                  background: index % 2 === 0 ? '#f9f9f9' : 'transparent',
                  borderRadius: '4px',
                  fontSize: '14px'
                }}
              >
                {index + 1}. {player.name}
                {player.email && (
                  <span style={{ fontSize: '12px', color: 'var(--text-secondary)', marginLeft: '10px' }}>
                    ({player.email})
                  </span>
                )}
              </div>
            ))}
          </div>
        )}

        {showPlayers && players.length === 0 && (
          <p style={{ fontSize: '14px', color: 'var(--text-secondary)', marginTop: '10px', textAlign: 'center' }}>
            No players added yet
          </p>
        )}
      </div>
    </div>
  );
}

export default Teams;
