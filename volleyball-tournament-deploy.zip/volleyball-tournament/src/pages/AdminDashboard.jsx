import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { signOut } from '../services/authService';
import {
  getAllTeams,
  getAllPlayers,
  getAllMatches,
  getAllCourts,
  createTeam,
  createPlayer,
  createMatch,
  createCourt,
  updateMatch,
  updateMatchScore,
  deleteTeam,
  deletePlayer,
  deleteMatch,
  isPlayerAvailable,
  subscribeToMatches
} from '../services/tournamentService';
import { format } from 'date-fns';

// Helper function to normalize court display
const normalizeCourtDisplay = (courtNumber) => {
  if (!courtNumber) return '';
  // Remove "Court" prefix if present (case-insensitive)
  return courtNumber.toString().replace(/^court\s*/i, '');
};

function AdminDashboard() {
  const [activeTab, setActiveTab] = useState('overview');
  const [teams, setTeams] = useState([]);
  const [players, setPlayers] = useState([]);
  const [matches, setMatches] = useState([]);
  const [courts, setCourts] = useState([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    loadData();
    
    const unsubscribe = subscribeToMatches((liveMatches) => {
      setMatches(liveMatches);
    });

    return () => unsubscribe();
  }, []);

  const loadData = async () => {
    try {
      const [teamsData, playersData, matchesData, courtsData] = await Promise.all([
        getAllTeams(),
        getAllPlayers(),
        getAllMatches(),
        getAllCourts()
      ]);
      
      setTeams(teamsData);
      setPlayers(playersData);
      setMatches(matchesData);
      setCourts(courtsData);
      setLoading(false);
    } catch (error) {
      console.error('Error loading data:', error);
      setLoading(false);
    }
  };

  const handleLogout = async () => {
    await signOut();
    navigate('/');
  };

  if (loading) {
    return (
      <div className="container">
        <div className="loading">
          <div className="spinner"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="container">
      <div className="card">
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px' }}>
          <h2 className="card-title">Admin Dashboard</h2>
          <button className="btn btn-error" onClick={handleLogout}>
            Logout
          </button>
        </div>

        <div style={{ display: 'flex', gap: '10px', marginBottom: '20px', flexWrap: 'wrap' }}>
          <button
            className={`btn ${activeTab === 'overview' ? 'btn-primary' : 'btn-secondary'}`}
            onClick={() => setActiveTab('overview')}
          >
            Overview
          </button>
          <button
            className={`btn ${activeTab === 'teams' ? 'btn-primary' : 'btn-secondary'}`}
            onClick={() => setActiveTab('teams')}
          >
            Teams ({teams.length})
          </button>
          <button
            className={`btn ${activeTab === 'players' ? 'btn-primary' : 'btn-secondary'}`}
            onClick={() => setActiveTab('players')}
          >
            Players ({players.length})
          </button>
          <button
            className={`btn ${activeTab === 'matches' ? 'btn-primary' : 'btn-secondary'}`}
            onClick={() => setActiveTab('matches')}
          >
            Matches ({matches.length})
          </button>
          <button
            className={`btn ${activeTab === 'courts' ? 'btn-primary' : 'btn-secondary'}`}
            onClick={() => setActiveTab('courts')}
          >
            Courts ({courts.length})
          </button>
          <button
            className={`btn ${activeTab === 'live' ? 'btn-success' : 'btn-secondary'}`}
            onClick={() => setActiveTab('live')}
          >
            Live Control
          </button>
        </div>

        {activeTab === 'overview' && <OverviewTab teams={teams} players={players} matches={matches} courts={courts} />}
        {activeTab === 'teams' && <TeamsTab teams={teams} onUpdate={loadData} />}
        {activeTab === 'players' && <PlayersTab players={players} teams={teams} onUpdate={loadData} />}
        {activeTab === 'matches' && <MatchesTab matches={matches} teams={teams} courts={courts} players={players} onUpdate={loadData} />}
        {activeTab === 'courts' && <CourtsTab courts={courts} onUpdate={loadData} />}
        {activeTab === 'live' && <LiveControlTab matches={matches} players={players} onUpdate={loadData} />}
      </div>
    </div>
  );
}

// Overview Tab
function OverviewTab({ teams, players, matches, courts }) {
  const ongoingMatches = matches.filter(m => m.status === 'ongoing');
  const upcomingMatches = matches.filter(m => m.status === 'scheduled');
  const completedMatches = matches.filter(m => m.status === 'completed');

  return (
    <div>
      <h3 style={{ marginBottom: '20px' }}>Tournament Statistics</h3>
      <div className="grid grid-3">
        <StatCard title="Total Teams" value={teams.length} color="var(--primary-color)" />
        <StatCard title="Total Players" value={players.length} color="var(--success-color)" />
        <StatCard title="Courts" value={courts.length} color="var(--warning-color)" />
        <StatCard title="Live Matches" value={ongoingMatches.length} color="var(--error-color)" />
        <StatCard title="Upcoming" value={upcomingMatches.length} color="var(--primary-color)" />
        <StatCard title="Completed" value={completedMatches.length} color="var(--secondary-color)" />
      </div>

      {ongoingMatches.length > 0 && (
        <div style={{ marginTop: '30px' }}>
          <h3 style={{ marginBottom: '15px' }}>Live Matches</h3>
          {ongoingMatches.map(match => (
            <div key={match.id} className="match-card ongoing" style={{ marginBottom: '10px' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <div>
                  <span className="court-tag">Court {normalizeCourtDisplay(match.courtNumber)}</span>
                  <span style={{ marginLeft: '10px', fontWeight: '600' }}>
                    {match.team1Name} vs {match.team2Name}
                  </span>
                </div>
                <div style={{ fontSize: '24px', fontWeight: '700', color: 'var(--primary-color)' }}>
                  {match.team1Score} - {match.team2Score}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function StatCard({ title, value, color }) {
  return (
    <div style={{ 
      padding: '20px', 
      background: 'white', 
      borderRadius: '8px', 
      textAlign: 'center',
      border: `2px solid ${color}`
    }}>
      <div style={{ fontSize: '36px', fontWeight: '700', color, marginBottom: '5px' }}>
        {value}
      </div>
      <div style={{ fontSize: '14px', color: 'var(--text-secondary)' }}>
        {title}
      </div>
    </div>
  );
}

// Teams Tab
function TeamsTab({ teams, onUpdate }) {
  const [showModal, setShowModal] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    category: 'Men',
    captainName: '',
    captainEmail: '',
    captainPhone: ''
  });

  const handleSubmit = async (e) => {
    e.preventDefault();
    await createTeam(formData);
    setShowModal(false);
    setFormData({ name: '', category: 'Men', captainName: '', captainEmail: '', captainPhone: '' });
    onUpdate();
  };

  const handleDelete = async (teamId) => {
    if (window.confirm('Are you sure you want to delete this team?')) {
      await deleteTeam(teamId);
      onUpdate();
    }
  };

  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px' }}>
        <h3>Manage Teams</h3>
        <button className="btn btn-primary" onClick={() => setShowModal(true)}>
          + Add Team
        </button>
      </div>

      <div className="grid grid-2">
        {teams.map(team => (
          <div key={team.id} className="card" style={{ margin: 0 }}>
            <h4 style={{ marginBottom: '10px' }}>{team.name}</h4>
            <p><strong>Category:</strong> {team.category}</p>
            <p><strong>Captain:</strong> {team.captainName}</p>
            <p><strong>Email:</strong> {team.captainEmail}</p>
            <p><strong>Phone:</strong> {team.captainPhone}</p>
            <button 
              className="btn btn-error" 
              style={{ marginTop: '10px', width: '100%' }}
              onClick={() => handleDelete(team.id)}
            >
              Delete
            </button>
          </div>
        ))}
      </div>

      {showModal && (
        <div className="modal-overlay" onClick={() => setShowModal(false)}>
          <div className="modal" onClick={(e) => e.stopPropagation()}>
            <h3 className="modal-title">Add New Team</h3>
            <form onSubmit={handleSubmit}>
              <div className="form-group">
                <label className="form-label">Team Name *</label>
                <input
                  className="form-input"
                  value={formData.name}
                  onChange={(e) => setFormData({...formData, name: e.target.value})}
                  required
                />
              </div>
              <div className="form-group">
                <label className="form-label">Category *</label>
                <select
                  className="form-select"
                  value={formData.category}
                  onChange={(e) => setFormData({...formData, category: e.target.value})}
                >
                  <option value="Men">Men</option>
                  <option value="Women">Women</option>
                </select>
              </div>
              <div className="form-group">
                <label className="form-label">Captain Name *</label>
                <input
                  className="form-input"
                  value={formData.captainName}
                  onChange={(e) => setFormData({...formData, captainName: e.target.value})}
                  required
                />
              </div>
              <div className="form-group">
                <label className="form-label">Captain Email</label>
                <input
                  type="email"
                  className="form-input"
                  value={formData.captainEmail}
                  onChange={(e) => setFormData({...formData, captainEmail: e.target.value})}
                />
              </div>
              <div className="form-group">
                <label className="form-label">Captain Phone</label>
                <input
                  className="form-input"
                  value={formData.captainPhone}
                  onChange={(e) => setFormData({...formData, captainPhone: e.target.value})}
                />
              </div>
              <div className="modal-footer">
                <button type="button" className="btn btn-secondary" onClick={() => setShowModal(false)}>
                  Cancel
                </button>
                <button type="submit" className="btn btn-primary">
                  Add Team
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

// Players Tab
function PlayersTab({ players, teams, onUpdate }) {
  const [showModal, setShowModal] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    teamId: ''
  });
  const [error, setError] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    
    try {
      const team = teams.find(t => t.id === formData.teamId);
      await createPlayer({
        ...formData,
        teamName: team?.name || ''
      });
      setShowModal(false);
      setFormData({ name: '', email: '', teamId: '' });
      onUpdate();
    } catch (err) {
      setError(err.message || 'Failed to add player. Please try again.');
    }
  };

  const handleDelete = async (playerId) => {
    if (window.confirm('Are you sure you want to delete this player?')) {
      await deletePlayer(playerId);
      onUpdate();
    }
  };

  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px' }}>
        <h3>Manage Players</h3>
        <button className="btn btn-primary" onClick={() => setShowModal(true)}>
          + Add Player
        </button>
      </div>

      <table style={{ width: '100%', borderCollapse: 'collapse' }}>
        <thead>
          <tr style={{ background: 'var(--bg-color)', textAlign: 'left' }}>
            <th style={{ padding: '10px' }}>Name</th>
            <th style={{ padding: '10px' }}>Email</th>
            <th style={{ padding: '10px' }}>Team</th>
            <th style={{ padding: '10px' }}>Actions</th>
          </tr>
        </thead>
        <tbody>
          {players.map(player => (
            <tr key={player.id} style={{ borderBottom: '1px solid var(--border-color)' }}>
              <td style={{ padding: '10px' }}>{player.name}</td>
              <td style={{ padding: '10px' }}>{player.email}</td>
              <td style={{ padding: '10px' }}>{player.teamName}</td>
              <td style={{ padding: '10px' }}>
                <button className="btn btn-error" onClick={() => handleDelete(player.id)}>
                  Delete
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      {showModal && (
        <div className="modal-overlay" onClick={() => setShowModal(false)}>
          <div className="modal" onClick={(e) => e.stopPropagation()}>
            <h3 className="modal-title">Add New Player</h3>
            
            {error && (
              <div style={{
                padding: '12px',
                background: '#ffebee',
                color: '#c62828',
                borderRadius: '8px',
                marginBottom: '15px',
                fontSize: '14px'
              }}>
                {error}
              </div>
            )}
            
            <form onSubmit={handleSubmit}>
              <div className="form-group">
                <label className="form-label">Player Name *</label>
                <input
                  className="form-input"
                  value={formData.name}
                  onChange={(e) => setFormData({...formData, name: e.target.value})}
                  required
                />
              </div>
              <div className="form-group">
                <label className="form-label">Email *</label>
                <input
                  type="email"
                  className="form-input"
                  value={formData.email}
                  onChange={(e) => setFormData({...formData, email: e.target.value})}
                  required
                />
                <small style={{ color: 'var(--text-secondary)', display: 'block', marginTop: '5px' }}>
                  Each player must have a unique email address
                </small>
              </div>
              <div className="form-group">
                <label className="form-label">Team *</label>
                <select
                  className="form-select"
                  value={formData.teamId}
                  onChange={(e) => setFormData({...formData, teamId: e.target.value})}
                  required
                >
                  <option value="">-- Select Team --</option>
                  {teams.map(team => (
                    <option key={team.id} value={team.id}>{team.name}</option>
                  ))}
                </select>
              </div>
              <div className="modal-footer">
                <button type="button" className="btn btn-secondary" onClick={() => setShowModal(false)}>
                  Cancel
                </button>
                <button type="submit" className="btn btn-primary">
                  Add Player
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

// Matches Tab
function MatchesTab({ matches, teams, courts, players, onUpdate }) {
  const [showModal, setShowModal] = useState(false);
  const [editingMatch, setEditingMatch] = useState(null);
  const [error, setError] = useState('');
  const [formData, setFormData] = useState({
    team1Id: '',
    team2Id: '',
    courtId: '',
    scheduledTime: '',
    category: 'Men'
  });

  const formatMatchTime = (timestamp) => {
    if (!timestamp) return '';
    const date = timestamp.toDate ? timestamp.toDate() : 
                 timestamp instanceof Date ? timestamp : new Date(timestamp);
    return format(date, 'MMM dd, HH:mm');
  };

  const checkSchedulingConflicts = (scheduledTime, team1Id, team2Id, courtId, excludeMatchId = null) => {
    const newMatchTime = new Date(scheduledTime);
    const conflicts = [];

    // Check each existing match for conflicts
    for (const match of matches) {
      // Skip the match being edited
      if (excludeMatchId && match.id === excludeMatchId) continue;
      
      // Skip completed matches
      if (match.status === 'completed') continue;

      const existingMatchTime = match.scheduledTime.toDate 
        ? match.scheduledTime.toDate() 
        : new Date(match.scheduledTime);

      // Check if times are the same (within 5 minutes)
      const timeDiff = Math.abs(newMatchTime - existingMatchTime);
      const fiveMinutes = 5 * 60 * 1000;

      if (timeDiff < fiveMinutes) {
        // Check team conflicts
        if (match.team1Id === team1Id || match.team2Id === team1Id) {
          const team = teams.find(t => t.id === team1Id);
          conflicts.push(`Team ${team?.name} already has a match scheduled at this time`);
        }
        if (match.team1Id === team2Id || match.team2Id === team2Id) {
          const team = teams.find(t => t.id === team2Id);
          conflicts.push(`Team ${team?.name} already has a match scheduled at this time`);
        }

        // Check court conflict
        if (match.courtId === courtId) {
          const court = courts.find(c => c.id === courtId);
          conflicts.push(`Court ${court?.number} is already booked at this time`);
        }
      }
    }

    return conflicts;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');

    // Validate same team not selected twice (only for new matches, not when editing)
    if (!editingMatch && formData.team1Id === formData.team2Id) {
      setError('Cannot schedule a team to play against itself!');
      return;
    }

    // Check for scheduling conflicts (exclude the current match if editing)
    const conflicts = checkSchedulingConflicts(
      formData.scheduledTime, 
      formData.team1Id, 
      formData.team2Id, 
      formData.courtId,
      editingMatch?.id
    );

    if (conflicts.length > 0) {
      setError(conflicts.join('. '));
      return;
    }

    if (editingMatch) {
      // Update existing match (only time and court can be changed)
      const court = courts.find(c => c.id === formData.courtId);
      await updateMatch(editingMatch.id, {
        courtId: formData.courtId,
        courtNumber: court?.number || '',
        scheduledTime: new Date(formData.scheduledTime)
      });
    } else {
      // Create new match
      const team1 = teams.find(t => t.id === formData.team1Id);
      const team2 = teams.find(t => t.id === formData.team2Id);
      const court = courts.find(c => c.id === formData.courtId);

      await createMatch({
        ...formData,
        team1Name: team1?.name || '',
        team2Name: team2?.name || '',
        courtNumber: court?.number || '',
        scheduledTime: new Date(formData.scheduledTime)
      });
    }
    
    setShowModal(false);
    setEditingMatch(null);
    setFormData({ team1Id: '', team2Id: '', courtId: '', scheduledTime: '', category: 'Men' });
    setError('');
    onUpdate();
  };

  const handleEdit = (match) => {
    setEditingMatch(match);
    setFormData({
      team1Id: match.team1Id,
      team2Id: match.team2Id,
      courtId: match.courtId,
      scheduledTime: format(
        match.scheduledTime.toDate ? match.scheduledTime.toDate() : new Date(match.scheduledTime),
        "yyyy-MM-dd'T'HH:mm"
      ),
      category: match.category || 'Men'
    });
    setShowModal(true);
    setError('');
  };

  const handleDelete = async (matchId) => {
    if (window.confirm('Are you sure you want to delete this match?')) {
      await deleteMatch(matchId);
      onUpdate();
    }
  };

  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px' }}>
        <h3>Manage Matches</h3>
        <button className="btn btn-primary" onClick={() => {
          setEditingMatch(null);
          setFormData({ team1Id: '', team2Id: '', courtId: '', scheduledTime: '', category: 'Men' });
          setShowModal(true);
          setError('');
        }}>
          + Schedule Match
        </button>
      </div>

      {matches.map(match => (
        <div key={match.id} className={`match-card ${match.status}`} style={{ marginBottom: '10px' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <div>
              <span className="court-tag">Court {normalizeCourtDisplay(match.courtNumber)}</span>
              <span style={{ marginLeft: '10px' }}>
                {match.team1Name} vs {match.team2Name}
              </span>
              {match.scheduledTime && (
                <span style={{ marginLeft: '10px', fontSize: '14px', color: 'var(--text-secondary)' }}>
                  {format(match.scheduledTime.toDate ? match.scheduledTime.toDate() : new Date(match.scheduledTime), 'MMM dd, HH:mm')}
                </span>
              )}
            </div>
            <div style={{ display: 'flex', gap: '10px', alignItems: 'center' }}>
              <span className={`badge badge-${match.status === 'ongoing' ? 'success' : match.status === 'completed' ? 'info' : 'warning'}`}>
                {match.status}
              </span>
              {match.status !== 'completed' && (
                <button 
                  className="btn btn-secondary" 
                  onClick={() => handleEdit(match)}
                  style={{ padding: '6px 12px', fontSize: '14px' }}
                >
                  🕐 Reschedule
                </button>
              )}
              <button className="btn btn-error" onClick={() => handleDelete(match.id)}>
                Delete
              </button>
            </div>
          </div>
          {match.status === 'completed' && match.playerOfTheMatch && (
            <div style={{ 
              marginTop: '10px', 
              padding: '8px 12px', 
              background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
              borderRadius: '6px',
              color: 'white',
              fontSize: '13px',
              display: 'inline-flex',
              alignItems: 'center',
              gap: '6px'
            }}>
              <span>🏆</span>
              <span style={{ fontWeight: '600' }}>Player of the Match: {match.playerOfTheMatch.playerName}</span>
            </div>
          )}
        </div>
      ))}

      {showModal && (
        <div className="modal-overlay" onClick={() => {
          setShowModal(false);
          setEditingMatch(null);
          setError('');
        }}>
          <div className="modal" onClick={(e) => e.stopPropagation()}>
            <h3 className="modal-title">
              {editingMatch ? '🕐 Reschedule Match' : 'Schedule New Match'}
            </h3>
            
            {editingMatch && (
              <div style={{
                padding: '12px',
                background: '#fff3cd',
                color: '#856404',
                borderRadius: '8px',
                marginBottom: '15px',
                fontSize: '14px'
              }}>
                ℹ️ Rescheduling: <strong>{editingMatch.team1Name} vs {editingMatch.team2Name}</strong>
                <br />You can change the time and court below.
              </div>
            )}
            
            {error && (
              <div style={{
                padding: '12px',
                background: '#ffebee',
                color: '#c62828',
                borderRadius: '8px',
                marginBottom: '15px',
                fontSize: '14px'
              }}>
                ⚠️ {error}
              </div>
            )}
            
            <form onSubmit={handleSubmit}>
              <div className="form-group">
                <label className="form-label">Team 1 *</label>
                <select
                  className="form-select"
                  value={formData.team1Id}
                  onChange={(e) => setFormData({...formData, team1Id: e.target.value})}
                  required
                  disabled={!!editingMatch}
                  style={editingMatch ? { opacity: 0.6, cursor: 'not-allowed' } : {}}
                >
                  <option value="">-- Select Team --</option>
                  {teams.map(team => (
                    <option key={team.id} value={team.id}>{team.name}</option>
                  ))}
                </select>
              </div>
              <div className="form-group">
                <label className="form-label">Team 2 *</label>
                <select
                  className="form-select"
                  value={formData.team2Id}
                  onChange={(e) => setFormData({...formData, team2Id: e.target.value})}
                  required
                  disabled={!!editingMatch}
                  style={editingMatch ? { opacity: 0.6, cursor: 'not-allowed' } : {}}
                >
                  <option value="">-- Select Team --</option>
                  {teams.map(team => (
                    <option key={team.id} value={team.id}>{team.name}</option>
                  ))}
                </select>
              </div>
              <div className="form-group">
                <label className="form-label">Court *</label>
                <select
                  className="form-select"
                  value={formData.courtId}
                  onChange={(e) => setFormData({...formData, courtId: e.target.value})}
                  required
                >
                  <option value="">-- Select Court --</option>
                  {courts.map(court => (
                    <option key={court.id} value={court.id}>Court {normalizeCourtDisplay(court.number)}</option>
                  ))}
                </select>
              </div>
              <div className="form-group">
                <label className="form-label">Category</label>
                <select
                  className="form-select"
                  value={formData.category}
                  onChange={(e) => setFormData({...formData, category: e.target.value})}
                >
                  <option value="Men">Men</option>
                  <option value="Women">Women</option>
                </select>
              </div>
              <div className="form-group">
                <label className="form-label">Scheduled Time *</label>
                <input
                  type="datetime-local"
                  className="form-input"
                  value={formData.scheduledTime}
                  onChange={(e) => setFormData({...formData, scheduledTime: e.target.value})}
                  required
                />
                <small style={{ color: 'var(--text-secondary)', display: 'block', marginTop: '5px' }}>
                  System will check for team and court availability at this time
                </small>
              </div>
              <div className="modal-footer">
                <button type="button" className="btn btn-secondary" onClick={() => {
                  setShowModal(false);
                  setEditingMatch(null);
                  setError('');
                }}>
                  Cancel
                </button>
                <button type="submit" className="btn btn-primary">
                  {editingMatch ? '🕐 Update Time' : 'Schedule Match'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

// Courts Tab
function CourtsTab({ courts, onUpdate }) {
  const [showModal, setShowModal] = useState(false);
  const [courtNumber, setCourtNumber] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    await createCourt({ number: courtNumber });
    setShowModal(false);
    setCourtNumber('');
    onUpdate();
  };

  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px' }}>
        <h3>Manage Courts</h3>
        <button className="btn btn-primary" onClick={() => setShowModal(true)}>
          + Add Court
        </button>
      </div>

      <div className="grid grid-3">
        {courts.map(court => (
          <div key={court.id} className="card" style={{ margin: 0, textAlign: 'center' }}>
            <h2 style={{ fontSize: '48px', color: 'var(--primary-color)', marginBottom: '10px' }}>
              {normalizeCourtDisplay(court.number)}
            </h2>
            <span className={`badge ${court.isAvailable ? 'badge-success' : 'badge-error'}`}>
              {court.isAvailable ? 'Available' : 'In Use'}
            </span>
          </div>
        ))}
      </div>

      {showModal && (
        <div className="modal-overlay" onClick={() => setShowModal(false)}>
          <div className="modal" onClick={(e) => e.stopPropagation()}>
            <h3 className="modal-title">Add New Court</h3>
            <form onSubmit={handleSubmit}>
              <div className="form-group">
                <label className="form-label">Court Number/Name *</label>
                <input
                  className="form-input"
                  value={courtNumber}
                  onChange={(e) => setCourtNumber(e.target.value)}
                  required
                  placeholder="e.g., A, B, 1, 2"
                />
                <small style={{ color: 'var(--text-secondary)', display: 'block', marginTop: '5px' }}>
                  Enter just the identifier (A, B, 1, 2, etc.)
                </small>
              </div>
              <div className="modal-footer">
                <button type="button" className="btn btn-secondary" onClick={() => setShowModal(false)}>
                  Cancel
                </button>
                <button type="submit" className="btn btn-primary">
                  Add Court
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

// Live Control Tab
function LiveControlTab({ matches, players, onUpdate }) {
  const [selectedMatch, setSelectedMatch] = useState(null);
  const [showPlayerOfMatchModal, setShowPlayerOfMatchModal] = useState(false);
  const [matchToEnd, setMatchToEnd] = useState(null);
  const [selectedPlayer, setSelectedPlayer] = useState('');

  const ongoingMatches = matches.filter(m => m.status === 'ongoing');
  const scheduledMatches = matches.filter(m => m.status === 'scheduled');

  const formatMatchTime = (timestamp) => {
    if (!timestamp) return '';
    const date = timestamp.toDate ? timestamp.toDate() : 
                 timestamp instanceof Date ? timestamp : new Date(timestamp);
    return format(date, 'MMM dd, HH:mm');
  };

  const startMatch = async (matchId) => {
    await updateMatch(matchId, { status: 'ongoing', startedAt: new Date() });
    onUpdate();
  };

  const openPlayerOfMatchModal = (match) => {
    setMatchToEnd(match);
    setSelectedPlayer('');
    setShowPlayerOfMatchModal(true);
  };

  const endMatch = async () => {
    if (!matchToEnd) return;
    
    const updateData = {
      status: 'completed',
      completedAt: new Date()
    };

    // Add player of the match if selected
    if (selectedPlayer) {
      const player = players.find(p => p.id === selectedPlayer);
      if (player) {
        updateData.playerOfTheMatch = {
          playerId: player.id,
          playerName: player.name,
          teamId: player.teamId
        };
      }
    }

    await updateMatch(matchToEnd.id, updateData);
    setSelectedMatch(null);
    setShowPlayerOfMatchModal(false);
    setMatchToEnd(null);
    setSelectedPlayer('');
    onUpdate();
  };

  const updateScore = async (matchId, team1Score, team2Score) => {
    await updateMatchScore(matchId, team1Score, team2Score);
    onUpdate();
  };

  return (
    <div>
      <h3 style={{ marginBottom: '20px' }}>Live Match Control</h3>

      {ongoingMatches.length > 0 && (
        <div style={{ marginBottom: '30px' }}>
          <h4>Ongoing Matches</h4>
          {ongoingMatches.map(match => (
            <div key={match.id} className="match-card ongoing" style={{ marginBottom: '10px' }}>
              <div style={{ marginBottom: '15px' }}>
                <span className="court-tag">Court {normalizeCourtDisplay(match.courtNumber)}</span>
                <span className="live-indicator" style={{ marginLeft: '10px' }}>
                  <span className="live-dot"></span>
                  LIVE
                </span>
              </div>
              
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '15px' }}>
                <div style={{ flex: 1 }}>
                  <div className="team-name">{match.team1Name}</div>
                </div>
                <input
                  type="number"
                  value={match.team1Score}
                  onChange={(e) => updateScore(match.id, parseInt(e.target.value) || 0, match.team2Score)}
                  style={{ width: '80px', textAlign: 'center', fontSize: '24px', fontWeight: '700', padding: '5px' }}
                />
              </div>

              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '15px' }}>
                <div style={{ flex: 1 }}>
                  <div className="team-name">{match.team2Name}</div>
                </div>
                <input
                  type="number"
                  value={match.team2Score}
                  onChange={(e) => updateScore(match.id, match.team1Score, parseInt(e.target.value) || 0)}
                  style={{ width: '80px', textAlign: 'center', fontSize: '24px', fontWeight: '700', padding: '5px' }}
                />
              </div>

              <button 
                className="btn btn-error" 
                style={{ width: '100%' }}
                onClick={() => openPlayerOfMatchModal(match)}
              >
                End Match
              </button>
            </div>
          ))}
        </div>
      )}

      {scheduledMatches.length > 0 && (
        <div>
          <h4>Scheduled Matches</h4>
          {scheduledMatches.slice(0, 10).map(match => (
            <div key={match.id} className="match-card" style={{ marginBottom: '10px' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <div>
                  <span className="court-tag">Court {normalizeCourtDisplay(match.courtNumber)}</span>
                  <span style={{ marginLeft: '10px' }}>
                    {match.team1Name} vs {match.team2Name}
                  </span>
                  {match.scheduledTime && (
                    <span style={{ marginLeft: '10px', fontSize: '14px', color: 'var(--text-secondary)' }}>
                      {format(match.scheduledTime.toDate ? match.scheduledTime.toDate() : new Date(match.scheduledTime), 'MMM dd, HH:mm')}
                    </span>
                  )}
                </div>
                <button 
                  className="btn btn-success"
                  onClick={() => startMatch(match.id)}
                >
                  Start Match
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {ongoingMatches.length === 0 && scheduledMatches.length === 0 && (
        <p style={{ textAlign: 'center', color: 'var(--text-secondary)', padding: '40px' }}>
          No matches available
        </p>
      )}

      {showPlayerOfMatchModal && matchToEnd && (
        <div className="modal-overlay" onClick={() => setShowPlayerOfMatchModal(false)}>
          <div className="modal" onClick={(e) => e.stopPropagation()}>
            <h3 className="modal-title">End Match - Player of the Match</h3>
            <div style={{ marginBottom: '20px' }}>
              <p style={{ marginBottom: '10px', fontWeight: '600' }}>
                {matchToEnd.team1Name} {matchToEnd.team1Score} - {matchToEnd.team2Score} {matchToEnd.team2Name}
              </p>
              <p style={{ color: 'var(--text-secondary)', fontSize: '14px' }}>
                Select the Player of the Match (optional)
              </p>
            </div>
            
            <div className="form-group">
              <label className="form-label">Player of the Match</label>
              <select
                className="form-select"
                value={selectedPlayer}
                onChange={(e) => setSelectedPlayer(e.target.value)}
              >
                <option value="">-- No Selection --</option>
                <optgroup label={matchToEnd.team1Name}>
                  {players
                    .filter(p => p.teamId === matchToEnd.team1Id)
                    .map(player => (
                      <option key={player.id} value={player.id}>
                        {player.name} {player.jerseyNumber ? `(#${player.jerseyNumber})` : ''}
                      </option>
                    ))}
                </optgroup>
                <optgroup label={matchToEnd.team2Name}>
                  {players
                    .filter(p => p.teamId === matchToEnd.team2Id)
                    .map(player => (
                      <option key={player.id} value={player.id}>
                        {player.name} {player.jerseyNumber ? `(#${player.jerseyNumber})` : ''}
                      </option>
                    ))}
                </optgroup>
              </select>
            </div>

            <div className="modal-footer">
              <button
                type="button"
                className="btn btn-secondary"
                onClick={() => {
                  setShowPlayerOfMatchModal(false);
                  setMatchToEnd(null);
                  setSelectedPlayer('');
                }}
              >
                Cancel
              </button>
              <button
                type="button"
                className="btn btn-primary"
                onClick={endMatch}
              >
                End Match
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default AdminDashboard;
