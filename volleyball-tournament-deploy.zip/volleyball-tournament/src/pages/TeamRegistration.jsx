import React, { useState, useEffect } from 'react';
import { getAllTeams, createTeam, createPlayer, checkEmailExists } from '../services/tournamentService';

function TeamRegistration() {
  const [step, setStep] = useState(1); // 1: Team info, 2: Add players, 3: Success
  const [teams, setTeams] = useState([]);
  const [teamData, setTeamData] = useState({
    name: '',
    category: 'Men',
    captainName: '',
    captainEmail: '',
    captainPhone: '',
    captainJerseyNumber: '1'
  });
  const [players, setPlayers] = useState([]);
  const [currentPlayer, setCurrentPlayer] = useState({
    name: '',
    email: '',
    phone: '',
    jerseyNumber: ''
  });
  const [teamId, setTeamId] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    loadTeams();
  }, []);

  const loadTeams = async () => {
    const allTeams = await getAllTeams();
    setTeams(allTeams);
  };

  const handleTeamSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      // Check if captain email already exists
      const emailExists = await checkEmailExists(teamData.captainEmail);
      if (emailExists) {
        setError(`Email ${teamData.captainEmail} is already registered. Each player must have a unique email.`);
        setLoading(false);
        return;
      }

      // Check if team name already exists
      const teamExists = teams.find(t => t.name.toLowerCase() === teamData.name.toLowerCase());
      if (teamExists) {
        setError(`Team name "${teamData.name}" is already taken. Please choose a different name.`);
        setLoading(false);
        return;
      }

      // Add captain to players list (don't save to database yet)
      setPlayers([{
        name: teamData.captainName,
        email: teamData.captainEmail,
        phone: teamData.captainPhone,
        jerseyNumber: teamData.captainJerseyNumber,
        isCaptain: true
      }]);

      setStep(2);
      setLoading(false);
    } catch (err) {
      setError(err.message || 'Failed to validate. Please try again.');
      setLoading(false);
    }
  };

  const handleAddPlayer = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      // Validate email uniqueness
      const emailExists = await checkEmailExists(currentPlayer.email);
      if (emailExists) {
        setError(`Email ${currentPlayer.email} is already registered. Each player must have a unique email.`);
        setLoading(false);
        return;
      }

      // Validate jersey number uniqueness within team
      const jerseyExists = players.find(p => p.jerseyNumber === currentPlayer.jerseyNumber);
      if (jerseyExists) {
        setError(`Jersey number ${currentPlayer.jerseyNumber} is already taken in your team.`);
        setLoading(false);
        return;
      }

      // Add to local list only (don't save to database yet)
      setPlayers([...players, currentPlayer]);
      
      // Reset form
      setCurrentPlayer({
        name: '',
        email: '',
        phone: '',
        jerseyNumber: ''
      });
      
      setLoading(false);
    } catch (err) {
      setError(err.message || 'Failed to add player. Please try again.');
      setLoading(false);
    }
  };

  const handleFinish = async () => {
    setError('');
    setLoading(true);

    try {
      // Now save everything to database
      // 1. Create team
      const newTeam = await createTeam(teamData);
      setTeamId(newTeam.id);

      // 2. Add all players (including captain)
      for (const player of players) {
        await createPlayer({
          ...player,
          teamId: newTeam.id,
          teamName: teamData.name
        });
      }

      setStep(3);
      setLoading(false);
    } catch (err) {
      setError(err.message || 'Failed to complete registration. Please try again.');
      setLoading(false);
    }
  };

  const handleRemovePlayer = (index) => {
    const updatedPlayers = players.filter((_, i) => i !== index);
    setPlayers(updatedPlayers);
  };

  const handleReset = () => {
    setStep(1);
    setTeamData({
      name: '',
      category: 'Men',
      captainName: '',
      captainEmail: '',
      captainPhone: '',
      captainJerseyNumber: '1'
    });
    setPlayers([]);
    setCurrentPlayer({
      name: '',
      email: '',
      phone: '',
      jerseyNumber: ''
    });
    setTeamId('');
    setError('');
  };

  // Step 1: Team Information
  if (step === 1) {
    return (
      <div className="container">
        <div className="card" style={{ maxWidth: '600px', margin: '20px auto' }}>
          <div className="card-header">
            <h2 className="card-title">🏐 Team Registration</h2>
            <p style={{ color: 'var(--text-secondary)', marginTop: '10px' }}>
              Register your team for the Zoho Volleyball Tournament
            </p>
          </div>

          {error && (
            <div style={{
              padding: '15px',
              background: '#ffebee',
              color: '#c62828',
              borderRadius: '8px',
              marginBottom: '20px'
            }}>
              {error}
            </div>
          )}

          <form onSubmit={handleTeamSubmit}>
            <div className="form-group">
              <label className="form-label">Team Name *</label>
              <input
                className="form-input"
                value={teamData.name}
                onChange={(e) => setTeamData({...teamData, name: e.target.value})}
                placeholder="Enter your team name"
                required
              />
            </div>

            <div className="form-group">
              <label className="form-label">Category *</label>
              <select
                className="form-select"
                value={teamData.category}
                onChange={(e) => setTeamData({...teamData, category: e.target.value})}
                required
              >
                <option value="Men">Men's</option>
                <option value="Women">Women's</option>
              </select>
            </div>

            <div style={{
              background: 'var(--primary-light)',
              padding: '15px',
              borderRadius: '8px',
              marginBottom: '20px'
            }}>
              <h3 style={{ fontSize: '16px', marginBottom: '15px' }}>Captain Details</h3>
              
              <div className="form-group">
                <label className="form-label">Captain Name *</label>
                <input
                  className="form-input"
                  value={teamData.captainName}
                  onChange={(e) => setTeamData({...teamData, captainName: e.target.value})}
                  placeholder="Enter captain's full name"
                  required
                />
              </div>

              <div className="form-group">
                <label className="form-label">Captain Email *</label>
                <input
                  type="email"
                  className="form-input"
                  value={teamData.captainEmail}
                  onChange={(e) => setTeamData({...teamData, captainEmail: e.target.value})}
                  placeholder="captain@zoho.com"
                  required
                />
                <small style={{ color: 'var(--text-secondary)', display: 'block', marginTop: '5px' }}>
                  This will be used to uniquely identify the captain
                </small>
              </div>

              <div className="form-group">
                <label className="form-label">Captain Phone *</label>
                <input
                  type="tel"
                  className="form-input"
                  value={teamData.captainPhone}
                  onChange={(e) => setTeamData({...teamData, captainPhone: e.target.value})}
                  placeholder="+91 9876543210"
                  required
                />
              </div>

              <div className="form-group">
                <label className="form-label">Captain Jersey Number *</label>
                <input
                  type="number"
                  className="form-input"
                  value={teamData.captainJerseyNumber}
                  onChange={(e) => setTeamData({...teamData, captainJerseyNumber: e.target.value})}
                  placeholder="1"
                  min="1"
                  max="99"
                  required
                />
              </div>
            </div>

            <button
              type="submit"
              className="btn btn-primary"
              style={{ width: '100%' }}
              disabled={loading}
            >
              {loading ? 'Validating...' : 'Next: Add Players'}
            </button>
          </form>
        </div>
      </div>
    );
  }

  // Step 2: Add Players
  if (step === 2) {
    return (
      <div className="container">
        <div className="card" style={{ maxWidth: '800px', margin: '20px auto' }}>
          <div className="card-header">
            <h2 className="card-title">Add Team Members</h2>
            <p style={{ color: 'var(--text-secondary)', marginTop: '10px' }}>
              Team: <strong>{teamData.name}</strong> • Players: {players.length}
            </p>
            <p style={{ 
              background: '#fff3cd', 
              color: '#856404', 
              padding: '10px', 
              borderRadius: '8px', 
              marginTop: '10px',
              fontSize: '14px'
            }}>
              ℹ️ Your team will be saved when you click "Finish Registration" with at least 6 players.
            </p>
          </div>

          {error && (
            <div style={{
              padding: '15px',
              background: '#ffebee',
              color: '#c62828',
              borderRadius: '8px',
              marginBottom: '20px'
            }}>
              {error}
            </div>
          )}

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '30px' }}>
            {/* Add Player Form */}
            <div>
              <h3 style={{ fontSize: '16px', marginBottom: '15px' }}>Add New Player</h3>
              <form onSubmit={handleAddPlayer}>
                <div className="form-group">
                  <label className="form-label">Player Name *</label>
                  <input
                    className="form-input"
                    value={currentPlayer.name}
                    onChange={(e) => setCurrentPlayer({...currentPlayer, name: e.target.value})}
                    placeholder="Enter player's full name"
                    required
                  />
                </div>

                <div className="form-group">
                  <label className="form-label">Email *</label>
                  <input
                    type="email"
                    className="form-input"
                    value={currentPlayer.email}
                    onChange={(e) => setCurrentPlayer({...currentPlayer, email: e.target.value})}
                    placeholder="player@zoho.com"
                    required
                  />
                </div>

                <div className="form-group">
                  <label className="form-label">Phone</label>
                  <input
                    type="tel"
                    className="form-input"
                    value={currentPlayer.phone}
                    onChange={(e) => setCurrentPlayer({...currentPlayer, phone: e.target.value})}
                    placeholder="+91 9876543210"
                  />
                </div>

                <div className="form-group">
                  <label className="form-label">Jersey Number *</label>
                  <input
                    type="number"
                    className="form-input"
                    value={currentPlayer.jerseyNumber}
                    onChange={(e) => setCurrentPlayer({...currentPlayer, jerseyNumber: e.target.value})}
                    placeholder="2"
                    min="1"
                    max="99"
                    required
                  />
                </div>

                <button
                  type="submit"
                  className="btn btn-primary"
                  style={{ width: '100%' }}
                  disabled={loading}
                >
                  {loading ? 'Adding...' : '+ Add Player'}
                </button>
              </form>
            </div>

            {/* Players List */}
            <div>
              <h3 style={{ fontSize: '16px', marginBottom: '15px' }}>Team Roster ({players.length})</h3>
              <div style={{
                maxHeight: '400px',
                overflowY: 'auto',
                border: '1px solid var(--border-color)',
                borderRadius: '8px',
                padding: '10px'
              }}>
                {players.length === 0 ? (
                  <p style={{ color: 'var(--text-secondary)', textAlign: 'center', padding: '20px' }}>
                    No players added yet
                  </p>
                ) : (
                  players.map((player, index) => (
                    <div
                      key={index}
                      style={{
                        padding: '12px',
                        background: player.isCaptain ? 'var(--primary-light)' : 'var(--card-bg)',
                        border: '1px solid var(--border-color)',
                        borderRadius: '8px',
                        marginBottom: '8px',
                        display: 'flex',
                        alignItems: 'center',
                        gap: '10px'
                      }}
                    >
                      <div style={{
                        width: '40px',
                        height: '40px',
                        background: 'var(--primary-color)',
                        color: 'white',
                        borderRadius: '50%',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        fontWeight: 'bold',
                        flexShrink: 0
                      }}>
                        #{player.jerseyNumber}
                      </div>
                      <div style={{ flex: 1 }}>
                        <div style={{ fontWeight: '600' }}>
                          {player.name}
                          {player.isCaptain && (
                            <span style={{
                              marginLeft: '8px',
                              fontSize: '12px',
                              background: 'var(--primary-color)',
                              color: 'white',
                              padding: '2px 8px',
                              borderRadius: '12px'
                            }}>
                              Captain
                            </span>
                          )}
                        </div>
                        <div style={{ fontSize: '14px', color: 'var(--text-secondary)' }}>
                          {player.email}
                        </div>
                      </div>
                      {!player.isCaptain && (
                        <button
                          onClick={() => handleRemovePlayer(index)}
                          style={{
                            background: '#ffebee',
                            color: '#c62828',
                            border: 'none',
                            borderRadius: '6px',
                            padding: '6px 12px',
                            cursor: 'pointer',
                            fontSize: '14px',
                            flexShrink: 0
                          }}
                        >
                          Remove
                        </button>
                      )}
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>

          <div style={{
            marginTop: '30px',
            padding: '20px',
            background: 'var(--primary-light)',
            borderRadius: '8px',
            textAlign: 'center'
          }}>
            <p style={{ marginBottom: '15px' }}>
              {players.length < 6 ? (
                <>⚠️ Minimum 6 players required to complete registration (Currently: {players.length})</>
              ) : (
                <>✅ You have {players.length} players registered. You can add more or finish registration.</>
              )}
            </p>
            <div style={{ display: 'flex', gap: '10px', justifyContent: 'center' }}>
              <button
                className="btn btn-secondary"
                onClick={() => setStep(1)}
                disabled={loading}
                style={{ minWidth: '150px' }}
              >
                ← Back to Team Info
              </button>
              <button
                className="btn btn-primary"
                onClick={handleFinish}
                disabled={players.length < 6 || loading}
                style={{ minWidth: '200px' }}
              >
                {loading ? 'Saving Team...' : 'Finish Registration'}
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Step 3: Success
  if (step === 3) {
    return (
      <div className="container">
        <div className="card" style={{ maxWidth: '600px', margin: '50px auto', textAlign: 'center' }}>
          <div style={{ padding: '40px 20px' }}>
            <div style={{ fontSize: '64px', marginBottom: '20px' }}>🎉</div>
            <h2 style={{ color: 'var(--success-color)', marginBottom: '10px' }}>
              Registration Complete!
            </h2>
            <p style={{ fontSize: '18px', marginBottom: '30px' }}>
              Team <strong>{teamData.name}</strong> has been successfully registered
            </p>
            
            <div style={{
              background: 'var(--card-bg)',
              padding: '20px',
              borderRadius: '8px',
              marginBottom: '30px',
              textAlign: 'left'
            }}>
              <h3 style={{ fontSize: '16px', marginBottom: '15px' }}>Registration Summary</h3>
              <div style={{ display: 'grid', gap: '10px' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                  <span style={{ color: 'var(--text-secondary)' }}>Team Name:</span>
                  <strong>{teamData.name}</strong>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                  <span style={{ color: 'var(--text-secondary)' }}>Category:</span>
                  <strong>{teamData.category}</strong>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                  <span style={{ color: 'var(--text-secondary)' }}>Captain:</span>
                  <strong>{teamData.captainName}</strong>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                  <span style={{ color: 'var(--text-secondary)' }}>Total Players:</span>
                  <strong>{players.length}</strong>
                </div>
              </div>
            </div>

            <p style={{ color: 'var(--text-secondary)', marginBottom: '20px' }}>
              Tournament organizers will review your registration and schedule matches soon.
            </p>

            <div style={{ display: 'flex', gap: '10px', justifyContent: 'center' }}>
              <button
                className="btn btn-secondary"
                onClick={handleReset}
              >
                Register Another Team
              </button>
              <button
                className="btn btn-primary"
                onClick={() => window.location.href = '/'}
              >
                Go to Home
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default TeamRegistration;
