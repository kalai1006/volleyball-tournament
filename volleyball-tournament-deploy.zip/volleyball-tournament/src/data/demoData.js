// Demo data for testing without Firebase
export const demoTeams = [
  {
    id: 'team1',
    name: 'Thunder Strikers',
    category: 'Men',
    captainName: 'Rajesh Kumar',
    captainEmail: 'rajesh.kumar@zoho.com',
    captainPhone: '+91 9876543210'
  },
  {
    id: 'team2',
    name: 'Lightning Bolts',
    category: 'Men',
    captainName: 'Amit Singh',
    captainEmail: 'amit.singh@zoho.com',
    captainPhone: '+91 9876543211'
  },
  {
    id: 'team3',
    name: 'Sky Warriors',
    category: 'Men',
    captainName: 'Priya Sharma',
    captainEmail: 'priya.sharma@zoho.com',
    captainPhone: '+91 9876543212'
  },
  {
    id: 'team4',
    name: 'Wave Riders',
    category: 'Men',
    captainName: 'Vikram Patel',
    captainEmail: 'vikram.patel@zoho.com',
    captainPhone: '+91 9876543213'
  },
  {
    id: 'team5',
    name: 'Storm Chasers',
    category: 'Women',
    captainName: 'Ananya Reddy',
    captainEmail: 'ananya.reddy@zoho.com',
    captainPhone: '+91 9876543214'
  },
  {
    id: 'team6',
    name: 'Phoenix Rising',
    category: 'Women',
    captainName: 'Kavya Menon',
    captainEmail: 'kavya.menon@zoho.com',
    captainPhone: '+91 9876543215'
  }
];

export const demoPlayers = [
  { id: 'p1', name: 'Rahul Verma', email: 'rahul.v@zoho.com', phone: '+91 9876543220', jerseyNumber: '5', teamId: 'team1', teamName: 'Thunder Strikers' },
  { id: 'p2', name: 'Arjun Nair', email: 'arjun.n@zoho.com', phone: '+91 9876543221', jerseyNumber: '7', teamId: 'team1', teamName: 'Thunder Strikers' },
  { id: 'p3', name: 'Karthik Iyer', email: 'karthik.i@zoho.com', phone: '+91 9876543222', jerseyNumber: '10', teamId: 'team1', teamName: 'Thunder Strikers' },
  { id: 'p4', name: 'Suresh Babu', email: 'suresh.b@zoho.com', phone: '+91 9876543223', jerseyNumber: '3', teamId: 'team2', teamName: 'Lightning Bolts' },
  { id: 'p5', name: 'Ramesh Kumar', email: 'ramesh.k@zoho.com', phone: '+91 9876543224', jerseyNumber: '8', teamId: 'team2', teamName: 'Lightning Bolts' },
  { id: 'p6', name: 'Deepak Raj', email: 'deepak.r@zoho.com', phone: '+91 9876543225', jerseyNumber: '11', teamId: 'team2', teamName: 'Lightning Bolts' },
  { id: 'p7', name: 'Naveen Kumar', email: 'naveen.k@zoho.com', phone: '+91 9876543226', jerseyNumber: '6', teamId: 'team3', teamName: 'Sky Warriors' },
  { id: 'p8', name: 'Manoj Singh', email: 'manoj.s@zoho.com', phone: '+91 9876543227', jerseyNumber: '9', teamId: 'team3', teamName: 'Sky Warriors' },
  { id: 'p9', name: 'Arun Kumar', email: 'arun.k@zoho.com', phone: '+91 9876543228', jerseyNumber: '4', teamId: 'team4', teamName: 'Wave Riders' },
  { id: 'p10', name: 'Vinay Sharma', email: 'vinay.s@zoho.com', phone: '+91 9876543229', jerseyNumber: '12', teamId: 'team4', teamName: 'Wave Riders' },
  { id: 'p11', name: 'Priya Nair', email: 'priya.n@zoho.com', phone: '+91 9876543230', jerseyNumber: '2', teamId: 'team5', teamName: 'Storm Chasers' },
  { id: 'p12', name: 'Sneha Reddy', email: 'sneha.r@zoho.com', phone: '+91 9876543231', jerseyNumber: '5', teamId: 'team5', teamName: 'Storm Chasers' },
  { id: 'p13', name: 'Divya Krishna', email: 'divya.k@zoho.com', phone: '+91 9876543232', jerseyNumber: '7', teamId: 'team5', teamName: 'Storm Chasers' },
  { id: 'p14', name: 'Lakshmi Priya', email: 'lakshmi.p@zoho.com', phone: '+91 9876543233', jerseyNumber: '3', teamId: 'team6', teamName: 'Phoenix Rising' },
  { id: 'p15', name: 'Meera Srinivas', email: 'meera.s@zoho.com', phone: '+91 9876543234', jerseyNumber: '8', teamId: 'team6', teamName: 'Phoenix Rising' }
];

const now = new Date();
const tomorrow = new Date(now.getTime() + 24 * 60 * 60 * 1000);

export const demoMatches = [
  {
    id: 'match1',
    team1Id: 'team1',
    team2Id: 'team2',
    team1Name: 'Thunder Strikers',
    team2Name: 'Lightning Bolts',
    team1Score: 21,
    team2Score: 18,
    courtId: 'court1',
    courtNumber: '1',
    status: 'ongoing',
    category: 'Men',
    scheduledTime: now,
    startedAt: now
  },
  {
    id: 'match2',
    team1Id: 'team5',
    team2Id: 'team6',
    team1Name: 'Storm Chasers',
    team2Name: 'Phoenix Rising',
    team1Score: 15,
    team2Score: 12,
    courtId: 'court2',
    courtNumber: '2',
    status: 'ongoing',
    category: 'Women',
    scheduledTime: now,
    startedAt: now
  },
  {
    id: 'match3',
    team1Id: 'team3',
    team2Id: 'team4',
    team1Name: 'Sky Warriors',
    team2Name: 'Wave Riders',
    team1Score: 0,
    team2Score: 0,
    courtId: 'court1',
    courtNumber: '1',
    status: 'scheduled',
    category: 'Men',
    scheduledTime: new Date(now.getTime() + 2 * 60 * 60 * 1000)
  },
  {
    id: 'match4',
    team1Id: 'team1',
    team2Id: 'team3',
    team1Name: 'Thunder Strikers',
    team2Name: 'Sky Warriors',
    team1Score: 0,
    team2Score: 0,
    courtId: 'court2',
    courtNumber: '2',
    status: 'scheduled',
    category: 'Men',
    scheduledTime: new Date(now.getTime() + 3 * 60 * 60 * 1000)
  },
  {
    id: 'match5',
    team1Id: 'team2',
    team2Id: 'team4',
    team1Name: 'Lightning Bolts',
    team2Name: 'Wave Riders',
    team1Score: 25,
    team2Score: 23,
    courtId: 'court1',
    courtNumber: '1',
    status: 'completed',
    category: 'Men',
    scheduledTime: new Date(now.getTime() - 2 * 60 * 60 * 1000),
    completedAt: new Date(now.getTime() - 1 * 60 * 60 * 1000),
    playerOfTheMatch: {
      playerId: 'player3',
      playerName: 'Emily Davis',
      teamId: 'team2'
    }
  }
];

export const demoCourts = [
  { id: 'court1', number: '1', isAvailable: false },
  { id: 'court2', number: '2', isAvailable: false }
];

export const demoCheckins = [];

// Check if Firebase is properly configured
export const isFirebaseConfigured = () => {
  const apiKey = import.meta.env.VITE_FIREBASE_API_KEY;
  return apiKey && apiKey !== 'your_api_key_here' && !apiKey.includes('placeholder');
};
