import { 
  collection, 
  doc, 
  getDocs, 
  getDoc, 
  addDoc, 
  updateDoc, 
  deleteDoc, 
  query, 
  where, 
  orderBy, 
  onSnapshot,
  serverTimestamp 
} from 'firebase/firestore';
import { db } from '../firebase/config';
import { 
  isFirebaseConfigured, 
  demoTeams, 
  demoPlayers, 
  demoMatches, 
  demoCourts, 
  demoCheckins 
} from '../data/demoData';

// Teams
export const teamsCollection = db ? collection(db, 'teams') : null;

export const getAllTeams = async () => {
  if (!isFirebaseConfigured()) {
    return Promise.resolve(demoTeams);
  }
  const snapshot = await getDocs(teamsCollection);
  return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
};

export const getTeam = async (teamId) => {
  if (!isFirebaseConfigured()) return null;
  const docRef = doc(db, 'teams', teamId);
  const docSnap = await getDoc(docRef);
  return docSnap.exists() ? { id: docSnap.id, ...docSnap.data() } : null;
};

export const createTeam = async (teamData) => {
  if (!isFirebaseConfigured()) {
    console.warn('Cannot create team in demo mode');
    return;
  }
  return await addDoc(teamsCollection, {
    ...teamData,
    createdAt: serverTimestamp(),
    updatedAt: serverTimestamp()
  });
};

export const updateTeam = async (teamId, teamData) => {
  if (!isFirebaseConfigured()) return;
  const docRef = doc(db, 'teams', teamId);
  return await updateDoc(docRef, {
    ...teamData,
    updatedAt: serverTimestamp()
  });
};

export const deleteTeam = async (teamId) => {
  if (!isFirebaseConfigured()) return;
  const docRef = doc(db, 'teams', teamId);
  return await deleteDoc(docRef);
};

// Players
export const playersCollection = db ? collection(db, 'players') : null;

export const getAllPlayers = async () => {
  if (!isFirebaseConfigured()) {
    return Promise.resolve(demoPlayers);
  }
  const snapshot = await getDocs(playersCollection);
  return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
};

export const getPlayersByTeam = async (teamId) => {
  if (!isFirebaseConfigured()) {
    return Promise.resolve(demoPlayers.filter(p => p.teamId === teamId));
  }
  const q = query(playersCollection, where('teamId', '==', teamId));
  const snapshot = await getDocs(q);
  return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
};

export const checkEmailExists = async (email, excludePlayerId = null) => {
  if (!isFirebaseConfigured()) {
    const existing = demoPlayers.find(p => p.email === email && p.id !== excludePlayerId);
    return Promise.resolve(!!existing);
  }
  const q = query(playersCollection, where('email', '==', email));
  const snapshot = await getDocs(q);
  
  if (excludePlayerId) {
    // When updating, exclude the current player's ID
    return snapshot.docs.some(doc => doc.id !== excludePlayerId);
  }
  
  return !snapshot.empty;
};

export const createPlayer = async (playerData) => {
  if (!isFirebaseConfigured()) return;
  
  // Check if email already exists
  const emailExists = await checkEmailExists(playerData.email);
  if (emailExists) {
    throw new Error(`Email ${playerData.email} is already registered to another player. Each player must have a unique email.`);
  }
  
  return await addDoc(playersCollection, {
    ...playerData,
    createdAt: serverTimestamp()
  });
};

export const updatePlayer = async (playerId, playerData) => {
  if (!isFirebaseConfigured()) return;
  
  // Check if email already exists (excluding current player)
  if (playerData.email) {
    const emailExists = await checkEmailExists(playerData.email, playerId);
    if (emailExists) {
      throw new Error(`Email ${playerData.email} is already registered to another player. Each player must have a unique email.`);
    }
  }
  
  const docRef = doc(db, 'players', playerId);
  return await updateDoc(docRef, playerData);
};

export const deletePlayer = async (playerId) => {
  if (!isFirebaseConfigured()) return;
  const docRef = doc(db, 'players', playerId);
  return await deleteDoc(docRef);
};

// Check if player is available for a match (not playing in another match at the same time)
export const isPlayerAvailable = async (playerId, matchTime, excludeMatchId = null) => {
  if (!isFirebaseConfigured()) return true;
  const matchesRef = collection(db, 'matches');
  const q = query(
    matchesRef,
    where('status', 'in', ['scheduled', 'ongoing']),
    where('scheduledTime', '==', matchTime)
  );
  
  const snapshot = await getDocs(q);
  const conflictingMatches = snapshot.docs
    .filter(doc => doc.id !== excludeMatchId)
    .filter(doc => {
      const match = doc.data();
      const team1Players = match.team1Players || [];
      const team2Players = match.team2Players || [];
      return [...team1Players, ...team2Players].includes(playerId);
    });
  
  return conflictingMatches.length === 0;
};

// Matches
export const matchesCollection = db ? collection(db, 'matches') : null;

export const getAllMatches = async () => {
  if (!isFirebaseConfigured()) {
    return Promise.resolve(demoMatches.sort((a, b) => a.scheduledTime - b.scheduledTime));
  }
  const q = query(matchesCollection, orderBy('scheduledTime', 'asc'));
  const snapshot = await getDocs(q);
  return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
};

export const getMatchesByDate = async (date) => {
  if (!isFirebaseConfigured()) {
    return Promise.resolve(demoMatches);
  }
  const startOfDay = new Date(date);
  startOfDay.setHours(0, 0, 0, 0);
  const endOfDay = new Date(date);
  endOfDay.setHours(23, 59, 59, 999);
  
  const q = query(
    matchesCollection,
    where('scheduledTime', '>=', startOfDay),
    where('scheduledTime', '<=', endOfDay),
    orderBy('scheduledTime', 'asc')
  );
  
  const snapshot = await getDocs(q);
  return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
};

export const getMatchesByCourt = async (courtId) => {
  if (!isFirebaseConfigured()) {
    return Promise.resolve(demoMatches.filter(m => m.courtId === courtId));
  }
  const q = query(
    matchesCollection,
    where('courtId', '==', courtId),
    orderBy('scheduledTime', 'asc')
  );
  const snapshot = await getDocs(q);
  return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
};

export const getOngoingMatches = async () => {
  if (!isFirebaseConfigured()) {
    return Promise.resolve(demoMatches.filter(m => m.status === 'ongoing'));
  }
  const q = query(matchesCollection, where('status', '==', 'ongoing'));
  const snapshot = await getDocs(q);
  return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
};

export const createMatch = async (matchData) => {
  if (!isFirebaseConfigured()) return;
  return await addDoc(matchesCollection, {
    ...matchData,
    status: 'scheduled',
    team1Score: 0,
    team2Score: 0,
    createdAt: serverTimestamp(),
    updatedAt: serverTimestamp()
  });
};

export const updateMatch = async (matchId, matchData) => {
  if (!isFirebaseConfigured()) return;
  const docRef = doc(db, 'matches', matchId);
  return await updateDoc(docRef, {
    ...matchData,
    updatedAt: serverTimestamp()
  });
};

export const updateMatchScore = async (matchId, team1Score, team2Score) => {
  if (!isFirebaseConfigured()) return;
  const docRef = doc(db, 'matches', matchId);
  return await updateDoc(docRef, {
    team1Score,
    team2Score,
    updatedAt: serverTimestamp()
  });
};

export const deleteMatch = async (matchId) => {
  if (!isFirebaseConfigured()) return;
  const docRef = doc(db, 'matches', matchId);
  return await deleteDoc(docRef);
};

// Courts
export const courtsCollection = db ? collection(db, 'courts') : null;

export const getAllCourts = async () => {
  if (!isFirebaseConfigured()) {
    return Promise.resolve(demoCourts);
  }
  const snapshot = await getDocs(courtsCollection);
  return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
};

export const createCourt = async (courtData) => {
  if (!isFirebaseConfigured()) return;
  return await addDoc(courtsCollection, {
    ...courtData,
    isAvailable: true,
    createdAt: serverTimestamp()
  });
};

export const updateCourt = async (courtId, courtData) => {
  if (!isFirebaseConfigured()) return;
  const docRef = doc(db, 'courts', courtId);
  return await updateDoc(docRef, courtData);
};

// Check-ins
export const checkinsCollection = db ? collection(db, 'checkins') : null;

export const createCheckin = async (checkinData) => {
  if (!isFirebaseConfigured()) return;
  return await addDoc(checkinsCollection, {
    ...checkinData,
    checkinTime: serverTimestamp()
  });
};

export const getCheckinByMatch = async (matchId) => {
  if (!isFirebaseConfigured()) {
    return Promise.resolve([]);
  }
  const q = query(checkinsCollection, where('matchId', '==', matchId));
  const snapshot = await getDocs(q);
  return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
};

export const submitTeamCheckin = async (checkinData) => {
  if (!isFirebaseConfigured()) {
    console.log('Demo mode: Team check-in submitted', checkinData);
    return Promise.resolve({ id: 'demo-checkin-' + Date.now() });
  }
  return await addDoc(checkinsCollection, {
    ...checkinData,
    checkinTime: serverTimestamp()
  });
};

export const getAllCheckins = async () => {
  if (!isFirebaseConfigured()) {
    return Promise.resolve([]);
  }
  const snapshot = await getDocs(checkinsCollection);
  return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
};

// Real-time listeners
export const subscribeToMatches = (callback) => {
  if (!isFirebaseConfigured()) {
    // Demo mode: simulate real-time updates
    callback(demoMatches.sort((a, b) => a.scheduledTime - b.scheduledTime));
    return () => {}; // Return empty unsubscribe function
  }
  const q = query(matchesCollection, orderBy('scheduledTime', 'asc'));
  return onSnapshot(q, (snapshot) => {
    const matches = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
    callback(matches);
  });
};

export const subscribeToTeams = (callback) => {
  if (!isFirebaseConfigured()) {
    callback(demoTeams);
    return () => {};
  }
  return onSnapshot(teamsCollection, (snapshot) => {
    const teams = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
    callback(teams);
  });
};

export const subscribeToPlayers = (callback) => {
  if (!isFirebaseConfigured()) {
    callback(demoPlayers);
    return () => {};
  }
  return onSnapshot(playersCollection, (snapshot) => {
    const players = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
    callback(players);
  });
};

export const subscribeToOngoingMatches = (callback) => {
  if (!isFirebaseConfigured()) {
    callback(demoMatches.filter(m => m.status === 'ongoing'));
    return () => {};
  }
  const q = query(matchesCollection, where('status', '==', 'ongoing'));
  return onSnapshot(q, (snapshot) => {
    const matches = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
    callback(matches);
  });
};
