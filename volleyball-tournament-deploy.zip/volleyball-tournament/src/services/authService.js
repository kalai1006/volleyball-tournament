import { signInWithEmailAndPassword, signOut as firebaseSignOut } from 'firebase/auth';
import { auth } from '../firebase/config';

export const signIn = async (email, password) => {
  if (!auth) {
    throw new Error('Firebase authentication is not configured. Please update the .env file.');
  }
  try {
    const userCredential = await signInWithEmailAndPassword(auth, email, password);
    return userCredential.user;
  } catch (error) {
    throw new Error(error.message);
  }
};

export const signOut = async () => {
  if (!auth) {
    throw new Error('Firebase authentication is not configured.');
  }
  try {
    await firebaseSignOut(auth);
  } catch (error) {
    throw new Error(error.message);
  }
};

export const getCurrentUser = () => {
  return auth ? auth.currentUser : null;
};
