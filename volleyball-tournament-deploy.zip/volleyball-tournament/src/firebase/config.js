// Firebase configuration template
// Replace these values with your actual Firebase project credentials
// Get these from Firebase Console > Project Settings > Your apps > SDK setup and configuration

import { initializeApp } from 'firebase/app';
import { getFirestore } from 'firebase/firestore';
import { getAuth } from 'firebase/auth';

const firebaseConfig = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY,
  authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN,
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID,
  storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET,
  messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID,
  appId: import.meta.env.VITE_FIREBASE_APP_ID
};

// Check if Firebase is configured with real credentials
const isConfigured = firebaseConfig.apiKey && 
                     firebaseConfig.apiKey !== 'your_api_key_here' && 
                     !firebaseConfig.apiKey.includes('placeholder');

// Initialize Firebase only if configured
let app = null;
let db = null;
let auth = null;

if (isConfigured) {
  try {
    app = initializeApp(firebaseConfig);
    db = getFirestore(app);
    auth = getAuth(app);
  } catch (error) {
    console.warn('Firebase initialization failed. Running in demo mode.', error);
  }
} else {
  console.info('🎭 Running in DEMO MODE - Firebase not configured. Using sample data.');
  console.info('To use real Firebase, update the .env file with your Firebase credentials.');
}

export { db, auth };
export default app;
