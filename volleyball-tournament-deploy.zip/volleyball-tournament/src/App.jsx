import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import { onAuthStateChanged } from 'firebase/auth';
import { auth } from './firebase/config';

// Pages
import HomePage from './pages/HomePage';
import AdminDashboard from './pages/AdminDashboard';
import LiveScores from './pages/LiveScores';
import Fixtures from './pages/Fixtures';
import Teams from './pages/Teams';
import CheckIn from './pages/CheckIn';
import Login from './pages/Login';
import TeamRegistration from './pages/TeamRegistration';

function App() {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Only set up auth listener if Firebase is configured
    if (auth) {
      const unsubscribe = onAuthStateChanged(auth, (currentUser) => {
        setUser(currentUser);
        setLoading(false);
      });

      return () => unsubscribe();
    } else {
      // In demo mode, just finish loading
      setLoading(false);
    }
  }, []);

  if (loading) {
    return (
      <div className="loading">
        <div className="spinner"></div>
      </div>
    );
  }

  return (
    <Router>
      <div className="app">
        <header className="header">
          <div className="header-content">
            <h1>🏐 Zoho Volleyball Tournament</h1>
            <nav className="header-nav">
              <Link to="/" style={{ color: 'white', textDecoration: 'none' }}>Home</Link>
              <Link to="/live" style={{ color: 'white', textDecoration: 'none' }}>Live Scores</Link>
              <Link to="/fixtures" style={{ color: 'white', textDecoration: 'none' }}>Fixtures</Link>
              <Link to="/teams" style={{ color: 'white', textDecoration: 'none' }}>Teams</Link>
              <Link to="/register" style={{ color: 'white', textDecoration: 'none' }}>Register Team</Link>
              <Link to="/checkin" style={{ color: 'white', textDecoration: 'none' }}>Check-in</Link>
              {user ? (
                <Link to="/admin" style={{ color: 'white', textDecoration: 'none' }}>Admin</Link>
              ) : (
                <Link to="/login" style={{ color: 'white', textDecoration: 'none' }}>Login</Link>
              )}
            </nav>
          </div>
        </header>

        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/live" element={<LiveScores />} />
          <Route path="/fixtures" element={<Fixtures />} />
          <Route path="/teams" element={<Teams />} />
          <Route path="/register" element={<TeamRegistration />} />
          <Route path="/checkin" element={<CheckIn />} />
          <Route path="/login" element={<Login />} />
          <Route path="/admin" element={user ? <AdminDashboard /> : <Login />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;
