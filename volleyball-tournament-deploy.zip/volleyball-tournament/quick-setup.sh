#!/bin/bash

# Zoho Volleyball Tournament - Quick Setup Script

echo "🏐 Zoho Volleyball Tournament - Quick Setup"
echo "=========================================="
echo ""

# Check if Node.js is installed
if ! command -v node &> /dev/null; then
    echo "❌ Node.js is not installed. Please install Node.js 18+ first."
    echo "   Download from: https://nodejs.org/"
    exit 1
fi

echo "✅ Node.js detected: $(node --version)"
echo ""

# Check if .env file exists
if [ ! -f .env ]; then
    echo "📝 Creating .env file from template..."
    cp .env.example .env
    echo "⚠️  Please edit .env file and add your Firebase configuration"
    echo "   Get your config from: https://console.firebase.google.com/"
    echo ""
    read -p "Press Enter after you've configured .env file..."
fi

# Install dependencies
echo "📦 Installing dependencies..."
npm install

if [ $? -ne 0 ]; then
    echo "❌ Failed to install dependencies"
    exit 1
fi

echo ""
echo "✅ Setup complete!"
echo ""
echo "📚 Next steps:"
echo "   1. Make sure you've configured Firebase (see SETUP_GUIDE.md)"
echo "   2. Run: npm run dev"
echo "   3. Open: http://localhost:3000"
echo ""
echo "🔐 Admin login: Go to /login route"
echo "📖 Full guide: Read SETUP_GUIDE.md"
echo ""
